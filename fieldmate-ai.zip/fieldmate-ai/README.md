# FieldMate AI

Real-estate field survey app: photograph a for-sale/for-rent sign, let AI extract the
details (price, phone, size, type), and browse everything on a real map with Smart
Nearby and Safety reporting.

This is a real Vite + React project — a converted, deployable version of the
Claude-artifact prototype. Two things had to change to work outside Claude's sandbox
(see [What changed vs. the Claude artifact](#what-changed-vs-the-claude-artifact)
below), everything else is the same code.

## Quick start (local dev)

```bash
npm install
npm run dev
```

Opens at http://localhost:5173. The AI camera feature won't work locally unless you
also run the Cloudflare Pages function locally (see below) — everything else
(catalog, map, nearby, safety, login) works with plain `npm run dev` since it only
needs the browser's localStorage.

To test the AI analyze endpoint locally too, use Wrangler instead of plain Vite:

```bash
npm install -g wrangler   # one-time
npm run build
wrangler pages dev dist --binding ANTHROPIC_API_KEY=sk-ant-...
```

## Deploying to Cloudflare Pages

1. Push this folder to a GitHub/GitLab repo (or use `wrangler pages deploy dist` directly).
2. In the Cloudflare dashboard: **Workers & Pages → Create → Pages → Connect to Git**
   (or "Upload assets" if deploying `dist/` directly without git).
3. Build settings:
   - **Build command**: `npm run build`
   - **Build output directory**: `dist`
   - **Root directory**: `/` (leave default, unless you moved this folder)
4. The `functions/api/analyze.js` file is auto-detected by Cloudflare Pages — no
   extra config needed for the Function itself.
5. **Set the secret**: Pages project → **Settings → Environment variables** → add
   `ANTHROPIC_API_KEY` (Production and Preview) with your real Anthropic API key,
   type **Secret**. Get a key at https://console.anthropic.com/settings/keys.
6. Deploy. Your app will be live at `<project>.pages.dev`.

Optional — Google Maps: this app can use the real Google Maps JavaScript API if
you have a key, or falls back to an always-working embedded map (CARTO/OpenStreetMap
tiles) if you don't. Either way, no build-time config needed: the key is entered
**inside the running app** (Smart Map page → "ตั้งค่า Google Maps") and stored in
that browser's localStorage. Get a key at
https://console.cloud.google.com/google/maps-apis if you want the real thing.

## Project structure

```
fieldmate-ai/
├── functions/api/analyze.js   # Cloudflare Pages Function — proxies to Anthropic (server-side key)
├── src/
│   ├── App.jsx                 # the whole app (all screens/components)
│   ├── main.jsx                # entry point, installs the storage shim
│   ├── lib/storage.js          # localStorage-backed replacement for window.storage
│   └── index.css               # Tailwind entry
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
└── postcss.config.js
```

## What changed vs. the Claude artifact

The Claude-artifact version of this app relied on two things that only exist inside
Claude's sandbox. Both are shimmed/replaced here so `App.jsx` itself needed almost no
edits:

1. **`window.storage`** (saved listings, incidents, favorites, session, etc.) — now
   backed by the browser's `localStorage` via `src/lib/storage.js`, installed as
   `window.storage` in `main.jsx`. Data lives per-device/per-browser. If you want data
   shared across users/devices, swap this file's internals for calls to your own
   database instead.
2. **AI photo analysis** — originally called `api.anthropic.com` directly with no key
   (Claude's sandbox handled auth invisibly). Now it calls `/api/analyze`, a Cloudflare
   Pages Function that holds the real `ANTHROPIC_API_KEY` server-side and proxies the
   request. Never put a real Anthropic key in client-side code.

Everything else — UI, map, Smart Nearby, Safety, login, compare, etc. — is unchanged.

## Known limitations (carried over from the prototype)

- Listing pin positions on the map are illustrative (deterministically scattered
  around a fixed Bangkok reference point), since the camera capture flow doesn't
  collect real GPS coordinates per photo yet. Wiring `navigator.geolocation` into the
  capture flow would be a natural next step.
- Login is local-only (no real backend/auth provider) — good for a demo, not for
  production user accounts.
