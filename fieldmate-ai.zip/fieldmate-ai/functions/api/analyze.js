// Cloudflare Pages Function — runs server-side, so this is the ONLY place the real
// Anthropic API key ever touches. Deployed automatically from the /functions folder.
// Set the secret in the Cloudflare dashboard: Pages project > Settings > Environment
// variables > Add variable (name: ANTHROPIC_API_KEY, type: secret).
//
// Check https://docs.anthropic.com/en/docs/about-claude/models for the current model
// string if "claude-sonnet-5" below has since changed.

export async function onRequestPost(context) {
  const { request, env } = context;

  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ error: "invalid JSON body" }, 400);
  }

  const { base64, mediaType, prompt } = body;
  if (!base64 || !prompt) {
    return json({ error: "missing base64 or prompt" }, 400);
  }

  if (!env.ANTHROPIC_API_KEY) {
    return json({ error: "ANTHROPIC_API_KEY is not configured on the server" }, 500);
  }

  try {
    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-5",
        max_tokens: 1000,
        messages: [
          {
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: mediaType || "image/jpeg", data: base64 } },
              { type: "text", text: prompt },
            ],
          },
        ],
      }),
    });

    const data = await anthropicRes.json();
    return json(data, anthropicRes.status);
  } catch (err) {
    return json({ error: String(err) }, 502);
  }
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}
