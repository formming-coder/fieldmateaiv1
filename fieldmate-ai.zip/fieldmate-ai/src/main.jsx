import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import storage from "./lib/storage.js";
import "./index.css";

// App.jsx calls window.storage.* everywhere (that's how it worked inside the Claude
// artifact). Installing the shim here means zero changes were needed in App.jsx itself.
window.storage = storage;

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
