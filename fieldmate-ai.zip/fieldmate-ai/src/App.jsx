import React, { useState, useEffect, useRef, useCallback } from "react";
import * as XLSX from "xlsx";
import {
  Camera, ClipboardList, Phone, MapPin, Tag, X, Trash2, Loader2,
  CheckCircle2, Search, ChevronRight, RotateCcw, Ruler, User,
  Pencil, Save, AlertTriangle, Building2, Home as HomeIcon,
  Landmark, Warehouse, Trees, PhoneCall, Copy, Check, Bell,
  Map as MapIcon, Database, Menu as MenuIcon, LocateFixed,
  Store, ShieldCheck, Dog, Construction, Settings,
  Info, HelpCircle, LogOut, Navigation, Layers, GraduationCap,
  HeartPulse, Route, Milestone, Scale, Plus, Minus,
  Droplets, Share2, Star, SlidersHorizontal, ChevronLeft, ChevronDown,
  Utensils, Fuel, ShoppingBag, TrainFront, Lightbulb, Grid3x3, ImagePlus,
  FileSpreadsheet, Upload, ListChecks,
} from "lucide-react";

// ---------- constants & helpers ----------

const PROPERTY_TYPES = ["บ้านเดี่ยว", "บ้านแฝด", "ทาวน์เฮาส์", "คอนโด", "ที่ดิน", "อาคารพาณิชย์", "โกดัง/โรงงาน", "อื่นๆ"];
const DEAL_TYPES = ["ขาย", "เช่า", "ขาย/เช่า"];

const TYPE_ICON = {
  "บ้านเดี่ยว": HomeIcon,
  "บ้านแฝด": HomeIcon,
  "ทาวน์เฮาส์": Building2,
  "คอนโด": Landmark,
  "ที่ดิน": Trees,
  "อาคารพาณิชย์": Building2,
  "ตึกแถว": Building2,
  "โกดัง/โรงงาน": Warehouse,
};

const TYPE_COLOR = {
  "ที่ดิน": "bg-red-500",
  "บ้านเดี่ยว": "bg-amber-400",
  "บ้านแฝด": "bg-orange-500",
  "ทาวน์เฮาส์": "bg-blue-500",
  "คอนโด": "bg-purple-500",
  "อาคารพาณิชย์": "bg-emerald-500",
  "ตึกแถว": "bg-emerald-500",
  "โกดัง/โรงงาน": "bg-gray-500",
  "อื่นๆ": "bg-neutral-400",
};

// hex equivalents of TYPE_COLOR, needed for real Google Maps marker icons (tailwind classes don't apply inside Google's canvas-rendered map)
const TYPE_HEX = {
  "ที่ดิน": "#ef4444",
  "บ้านเดี่ยว": "#fbbf24",
  "บ้านแฝด": "#f97316",
  "ทาวน์เฮาส์": "#3b82f6",
  "คอนโด": "#a855f7",
  "อาคารพาณิชย์": "#10b981",
  "ตึกแถว": "#10b981",
  "โกดัง/โรงงาน": "#6b7280",
  "อื่นๆ": "#a3a3a3",
};
const TYPE_COLOR_TEXT = {
  "ที่ดิน": "text-red-500",
  "บ้านเดี่ยว": "text-amber-500",
  "บ้านแฝด": "text-orange-500",
  "ทาวน์เฮาส์": "text-blue-500",
  "คอนโด": "text-purple-500",
  "อาคารพาณิชย์": "text-emerald-500",
  "โกดัง/โรงงาน": "text-gray-500",
  "อื่นๆ": "text-neutral-400",
};

const LEGEND_TYPES = ["ที่ดิน", "บ้านเดี่ยว", "บ้านแฝด", "ทาวน์เฮาส์", "คอนโด", "อาคารพาณิชย์"];

const MAP_FILTERS = ["ทั้งหมด", "ที่ดิน", "บ้านเดี่ยว", "ทาวน์เฮาส์", "คอนโด", "อื่นๆ"];

const DEFAULT_CENTER = { lat: 13.6895, lon: 100.5395 }; // ถนนพระราม 3, บางโพงพาง, ยานนาวา
const DEFAULT_LABEL = "ถนนพระราม 3, บางโพงพาง, ยานนาวา, กรุงเทพฯ";
const BANGKOK_CENTER = { lat: 13.7563, lon: 100.5018 };
const GMAPS_KEY_STORAGE = "settings:gmaps-api-key";

function haversineKm(a, b) {
  if (!a || !b) return null;
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLon = ((b.lon - a.lon) * Math.PI) / 180;
  const s1 = Math.sin(dLat / 2) ** 2 + Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(s1), Math.sqrt(1 - s1));
}
function formatDistance(km) {
  if (km == null) return null;
  return km < 1 ? `${Math.round(km * 1000)} ม.` : `${km.toFixed(1)} กม.`;
}

const PLACE_COORDS = {
  "ยานนาวา": { lat: 13.6900, lon: 100.5400 },
  "บางโพงพาง": { lat: 13.6892, lon: 100.5410 },
  "พระราม 3": { lat: 13.6870, lon: 100.5330 },
  "สาทร": { lat: 13.7180, lon: 100.5290 },
  "สีลม": { lat: 13.7280, lon: 100.5340 },
  "บางนา": { lat: 13.6680, lon: 100.6050 },
  "ลาดพร้าว": { lat: 13.8150, lon: 100.5980 },
  "หัวหมาก": { lat: 13.7570, lon: 100.6470 },
  "บางรัก": { lat: 13.7290, lon: 100.5230 },
  "กรุงเทพ": { lat: 13.7563, lon: 100.5018 },
};

const INCIDENT_TYPES = ["สุนัขดุ", "ก่อสร้าง", "น้ำท่วม", "อื่นๆ"];
const INCIDENT_ICON = { "สุนัขดุ": Dog, "ก่อสร้าง": Construction, "น้ำท่วม": Droplets, "อื่นๆ": AlertTriangle };

const NEARBY_RADII = [
  { label: "250 ม.", km: 0.25 },
  { label: "500 ม.", km: 0.5 },
  { label: "1 กม.", km: 1 },
  { label: "2 กม.", km: 2 },
];

const COMPARE_ROWS = [
  { label: "ประเภททรัพย์", get: (l) => l.propertyType || "-" },
  { label: "ขนาดที่ดิน", get: (l) => l.sizeInfo || "-" },
  { label: "ราคาประกาศ (บาท)", get: (l) => l.price || "-" },
  { label: "ราคา/หน่วย (บาท)", get: (l) => { const v = pricePerUnit(l.price, l.sizeInfo); return v ? v.toLocaleString() : "-"; } },
  { label: "ระยะทางจากทรัพย์หลัก", get: (l, subject) => { const d = haversineKm(listingCoords(subject), listingCoords(l)); return d != null ? formatDistance(d) : "-"; } },
  { label: "เบอร์โทร", get: (l) => l.phone || "-" },
  { label: "ทำเล", get: (l) => l.location || "-" },
];

// Points-of-interest categories for Smart Nearby. There is no connected Places API in
// this environment (no Google/Longdo key configured), so these are deterministically
// generated illustrative samples — same center+radius+category always yields the same
// list, so it behaves consistently, but the names/ratings are NOT real businesses.
// Swap generatePOIs() for a real Places/Overpass API call to make this live data.
const POI_CATEGORIES = [
  { key: "food", label: "ของอร่อย", icon: Utensils, color: "bg-amber-400", names: ["ร้านก๋วยเตี๋ยวเรือ", "ครัวคุณยาย", "Cafe De Smile", "ส้มตำปากแซ่บ", "Shabu Station", "ข้าวมันไก่ป้านุช", "ร้านลาบอีสาน", "ก๋วยเตี๋ยวเรืออยุธยา"] },
  { key: "fuel", label: "ปั๊มน้ำมัน", icon: Fuel, color: "bg-red-500", names: ["ปั๊ม ปตท.", "ปั๊มบางจาก", "ปั๊มเชลล์", "ปั๊มคาลเท็กซ์", "ปั๊ม พีที"] },
  { key: "hospital", label: "โรงพยาบาล", icon: HeartPulse, color: "bg-blue-500", names: ["คลินิกใกล้บ้าน", "โรงพยาบาลชุมชน", "ศูนย์การแพทย์", "คลินิกแพทย์แผนปัจจุบัน"] },
  { key: "school", label: "โรงเรียน", icon: GraduationCap, color: "bg-indigo-500", names: ["โรงเรียนอนุบาล", "โรงเรียนประถมศึกษา", "โรงเรียนมัธยม", "สถาบันกวดวิชา"] },
  { key: "mall", label: "ห้างสรรพสินค้า", icon: ShoppingBag, color: "bg-purple-500", names: ["ห้างสรรพสินค้า", "คอมมูนิตี้มอลล์", "ตลาดนัด", "ซูเปอร์มาร์เก็ต"] },
  { key: "transit", label: "รถไฟฟ้า", icon: TrainFront, color: "bg-cyan-500", names: ["สถานีรถไฟฟ้า"] },
];

function generatePOIs(center, radiusKm, category) {
  const h = hashStr(`${category.key}-${center.lat.toFixed(3)}-${center.lon.toFixed(3)}-${radiusKm}`);
  const count = Math.min(category.names.length + 2, 3 + (h % 4));
  const items = [];
  for (let i = 0; i < count; i++) {
    const seed = hashStr(`${category.key}-${i}-${h}`);
    const angle = (seed % 360) * (Math.PI / 180);
    const dist = 0.03 + (((seed >> 4) % 90) / 100) * radiusKm;
    const lat = center.lat + (Math.sin(angle) * dist) / 111;
    const lon = center.lon + (Math.cos(angle) * dist) / (111 * Math.cos((center.lat * Math.PI) / 180));
    const baseName = category.names[i % category.names.length];
    const name = i >= category.names.length ? `${baseName} ${Math.floor(i / category.names.length) + 1}` : baseName;
    items.push({
      id: `${category.key}-${i}-${h}`,
      name,
      lat,
      lon,
      rating: (35 + (seed % 15)) / 10,
      reviews: 20 + (seed % 200),
      category: category.key,
    });
  }
  return items.sort((a, b) => haversineKm(center, { lat: a.lat, lon: a.lon }) - haversineKm(center, { lat: b.lat, lon: b.lon }));
}

// ---------- real POI data via OpenStreetMap Overpass API (free, no key) ----------
// Best-effort: if the request fails/times out (network, CORS, or Overpass being busy),
// callers fall back to generatePOIs() above so the UI never breaks.

const OVERPASS_ENDPOINTS = ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"];

const OVERPASS_TAGS = {
  food: ['["amenity"="restaurant"]', '["amenity"="cafe"]', '["amenity"="fast_food"]'],
  fuel: ['["amenity"="fuel"]'],
  hospital: ['["amenity"="hospital"]', '["amenity"="clinic"]'],
  school: ['["amenity"="school"]'],
  mall: ['["shop"="mall"]', '["shop"="department_store"]'],
  transit: ['["railway"="station"]', '["station"="subway"]'],
};

function overpassQuery(categoryKey, center, radiusM) {
  const filters = OVERPASS_TAGS[categoryKey] || [];
  const clauses = filters.map((f) => `node${f}(around:${radiusM},${center.lat},${center.lon});`).join("\n");
  return `[out:json][timeout:10];(\n${clauses}\n);out body 25;`;
}

async function fetchOverpassPOIs(category, center, radiusKm) {
  const query = overpassQuery(category.key, center, Math.max(50, Math.round(radiusKm * 1000)));
  let lastErr;
  for (const endpoint of OVERPASS_ENDPOINTS) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 7000);
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `data=${encodeURIComponent(query)}`,
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (!res.ok) throw new Error(`overpass ${res.status}`);
      const data = await res.json();
      const items = (data.elements || [])
        .filter((el) => typeof el.lat === "number" && typeof el.lon === "number")
        .map((el) => ({
          id: `osm-${el.id}`,
          name: el.tags?.name || el.tags?.["name:en"] || category.label,
          lat: el.lat,
          lon: el.lon,
          rating: null,
          reviews: null,
          category: category.key,
        }));
      return items;
    } catch (e) {
      clearTimeout(timer);
      lastErr = e;
    }
  }
  throw lastErr || new Error("overpass failed");
}


function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// retries a flaky async call (e.g. window.storage / fetch) once before giving up,
// since most failures seen in practice are transient rather than permanent
async function withRetry(fn, attempts = 2, delayMs = 900) {
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
      console.warn(`[withRetry] attempt ${i + 1}/${attempts} failed:`, e);
      if (i < attempts - 1) await new Promise((r) => setTimeout(r, delayMs));
    }
  }
  throw lastErr;
}

// window.storage.set/delete can fail "silently" — resolving to null instead of
// throwing — so a bare `await window.storage.set(...)` can look like it succeeded
// when it didn't. These wrappers turn a null result into a thrown error (so it's
// visible and so withRetry actually retries it) instead of failing silently.
async function storageSet(key, value) {
  return withRetry(async () => {
    const result = await window.storage.set(key, value);
    if (!result) throw new Error(`storage.set returned null for key "${key}"`);
    return result;
  });
}
async function storageDelete(key) {
  return withRetry(async () => {
    const result = await window.storage.delete(key);
    if (!result) throw new Error(`storage.delete returned null for key "${key}"`);
    return result;
  });
}
async function storageGet(key) {
  return withRetry(() => window.storage.get(key));
}

// shown for imported listings that have no matched photo, so <img src> never breaks
const PLACEHOLDER_IMAGE =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300"><rect width="100%" height="100%" fill="#e5e7eb"/><text x="50%" y="50%" font-size="22" fill="#9ca3af" text-anchor="middle" dominant-baseline="middle" font-family="sans-serif">ไม่มีรูปภาพ</text></svg>`
  );

// ---------- Excel/CSV bulk import ----------

const IMPORT_FIELDS = [
  { key: "propertyType", label: "ประเภททรัพย์", keywords: ["ประเภททรัพย์", "ประเภท", "type"] },
  { key: "dealType", label: "ประเภทการขาย (ขาย/เช่า)", keywords: ["ประเภทการขาย", "ขาย/เช่า", "deal"] },
  { key: "price", label: "ราคา", keywords: ["ราคา", "price"] },
  { key: "phone", label: "เบอร์โทร", keywords: ["เบอร์", "โทร", "phone", "tel"] },
  { key: "contactName", label: "ผู้ติดต่อ / สำนักงาน", keywords: ["ผู้ติดต่อ", "นายหน้า", "ชื่อ", "contact"] },
  { key: "sizeInfo", label: "ขนาดพื้นที่", keywords: ["เนื้อที่", "ขนาด", "พื้นที่", "ไร่", "size"] },
  { key: "location", label: "ทำเล / ที่อยู่", keywords: ["ที่อยู่", "ทำเล", "location", "address"] },
  { key: "note", label: "หมายเหตุ", keywords: ["หมายเหตุ", "note", "รายละเอียด"] },
  { key: "imageFilenameCol", label: "ชื่อไฟล์รูปภาพ (ถ้ามีคอลัมน์นี้)", keywords: ["รูป", "ภาพ", "photo", "image", "ไฟล์"] },
];

function guessColumnMapping(headers) {
  const mapping = {};
  IMPORT_FIELDS.forEach((f) => {
    const found = headers.find((h) => f.keywords.some((k) => String(h).toLowerCase().includes(k.toLowerCase())));
    mapping[f.key] = found || "";
  });
  return mapping;
}

function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
}

// prefers the real GPS coordinate captured at photo time; falls back to a deterministic
// pseudo-coordinate scattered around the default center for older listings that don't
// have one (illustrative only in that case)
function listingCoords(listing) {
  if (typeof listing.lat === "number" && typeof listing.lon === "number" && !isNaN(listing.lat) && !isNaN(listing.lon)) {
    return { lat: listing.lat, lon: listing.lon };
  }
  const h = hashStr(listing.id);
  const angle = (h % 360) * (Math.PI / 180);
  const dist = 0.003 + ((h >> 8) % 100) / 100 * 0.012;
  return {
    lat: DEFAULT_CENTER.lat + Math.sin(angle) * dist,
    lon: DEFAULT_CENTER.lon + Math.cos(angle) * dist * 1.15,
  };
}

function geocodeGuess(text) {
  if (!text) return null;
  const found = Object.keys(PLACE_COORDS).find((k) => text.includes(k));
  return found ? PLACE_COORDS[found] : null;
}

function parseNumber(str) {
  if (!str) return null;
  const s = String(str);
  const million = /ล้าน/.test(s);
  const match = s.replace(/,/g, "").match(/[\d.]+/);
  if (!match) return null;
  let n = parseFloat(match[0]);
  if (isNaN(n)) return null;
  if (million) n *= 1000000;
  return n;
}

// Thai land-area units: 1 ไร่ = 4 งาน = 400 ตร.ว., 1 งาน = 100 ตร.ว.
function totalWah(rai, ngan, wah) {
  const r = parseFloat(rai) || 0;
  const n = parseFloat(ngan) || 0;
  const w = parseFloat(wah) || 0;
  return r * 400 + n * 100 + w;
}
function formatRaiNganWah(rai, ngan, wah) {
  const total = totalWah(rai, ngan, wah);
  if (total <= 0) return "";
  const parts = [];
  if (parseFloat(rai)) parts.push(`${rai} ไร่`);
  if (parseFloat(ngan)) parts.push(`${ngan} งาน`);
  if (parseFloat(wah) || parts.length === 0) parts.push(`${wah || 0} ตร.ว.`);
  // the total sq.wah leads the string so existing parseNumber(sizeInfo) calls
  // throughout the app keep computing correct price-per-unit values
  return `${total.toLocaleString()} ตร.ว. (${parts.join(" ")})`;
}

// best-effort parse of the free-text sizeInfo the AI reads off a sign back into
// separate ไร่/งาน/ตร.ว. fields, so the capture form can auto-fill them.
// Handles "2 ไร่ 1 งาน 50 ตร.ว.", deed-style "2-1-50", and a bare "200 ตร.ว.".
// Returns null (leaving the fields blank) when the text isn't a rai/ngan/wah
// measurement at all — e.g. it's in ตร.ม. (sqm), which is a different unit.
function parseRaiNganWah(text) {
  if (!text) return null;
  const s = String(text);
  if (/ตร\.?\s*ม\.?|ตารางเมตร/.test(s) && !/ไร่|งาน|ตร\.?\s*ว\.?|ตารางวา/.test(s)) return null;

  const raiMatch = s.match(/(\d+(?:\.\d+)?)\s*ไร่/);
  const nganMatch = s.match(/(\d+(?:\.\d+)?)\s*งาน/);
  const wahMatch = s.match(/(\d+(?:\.\d+)?)\s*(?:ตารางวา|ตร\.?\s*ว\.?)/);
  if (raiMatch || nganMatch || wahMatch) {
    return { rai: raiMatch ? raiMatch[1] : "", ngan: nganMatch ? nganMatch[1] : "", wah: wahMatch ? wahMatch[1] : "" };
  }

  // Thai land-deed shorthand: "ไร่-งาน-ตร.ว." e.g. "2-1-50" or "0-2-0"
  const deedMatch = s.match(/(\d+)\s*-\s*(\d+)\s*-\s*(\d+(?:\.\d+)?)/);
  if (deedMatch) return { rai: deedMatch[1], ngan: deedMatch[2], wah: deedMatch[3] };

  // a bare number with no unit words on a land sign is almost always ตร.ว.
  const bare = s.replace(/,/g, "").match(/^\s*(\d+(?:\.\d+)?)\s*$/);
  if (bare) return { rai: "", ngan: "", wah: bare[1] };

  return null;
}

function pricePerUnit(price, size) {
  const p = parseNumber(price);
  const s = parseNumber(size);
  if (!p || !s) return null;
  return Math.round(p / s);
}

function median(nums) {
  const arr = nums.filter((n) => n != null).sort((a, b) => a - b);
  if (arr.length === 0) return null;
  const mid = Math.floor(arr.length / 2);
  return arr.length % 2 ? arr[mid] : Math.round((arr[mid - 1] + arr[mid]) / 2);
}
function average(nums) {
  const arr = nums.filter((n) => n != null);
  if (arr.length === 0) return null;
  return Math.round(arr.reduce((a, b) => a + b, 0) / arr.length);
}

// Deterministic similarity heuristic (0-99%): penalizes mismatched property type,
// price/unit difference, size difference, and distance from the subject property.
function comparableScore(subject, comp) {
  let score = 100;
  if (subject.propertyType && comp.propertyType && subject.propertyType !== comp.propertyType) score -= 20;
  const subjPPU = pricePerUnit(subject.price, subject.sizeInfo);
  const compPPU = pricePerUnit(comp.price, comp.sizeInfo);
  if (subjPPU && compPPU) {
    const diffPct = Math.abs(subjPPU - compPPU) / subjPPU;
    score -= Math.min(20, Math.round(diffPct * 60));
  }
  const subjSize = parseNumber(subject.sizeInfo);
  const compSize = parseNumber(comp.sizeInfo);
  if (subjSize && compSize) {
    const diffPct = Math.abs(subjSize - compSize) / subjSize;
    score -= Math.min(15, Math.round(diffPct * 40));
  }
  const dist = haversineKm(listingCoords(subject), listingCoords(comp));
  if (dist != null) score -= Math.min(15, Math.round(dist * 8));
  return Math.max(45, Math.min(99, Math.round(score)));
}

function valuationEstimate(subject, comps) {
  const ppus = comps.map((c) => pricePerUnit(c.price, c.sizeInfo)).filter(Boolean);
  const subjSize = parseNumber(subject.sizeInfo);
  if (ppus.length === 0 || !subjSize) return null;
  const min = Math.min(...ppus);
  const max = Math.max(...ppus);
  const med = median(ppus);
  return {
    low: Math.round(min * subjSize),
    high: Math.round(max * subjSize),
    mid: Math.round(med * subjSize),
    avgPPU: average(ppus),
    medPPU: med,
    rangePPU: [min, max],
  };
}

function resizeImage(file, maxW = 640, quality = 0.55) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxW / img.width);
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// re-compresses an already-loaded data URL smaller, without needing the original File —
// used as a fallback when a save fails, in case the payload size was the problem
function recompressDataUrl(dataUrl, maxW, quality) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxW / img.width);
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL("image/jpeg", quality));
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}

function timeAgo(iso) {
  const diff = Math.max(0, Date.now() - new Date(iso).getTime());
  const min = Math.floor(diff / 60000);
  if (min < 1) return "เมื่อสักครู่";
  if (min < 60) return `${min} นาทีที่แล้ว`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr} ชม.ที่แล้ว`;
  const day = Math.floor(hr / 24);
  if (day < 7) return `${day} วันที่แล้ว`;
  return new Date(iso).toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "2-digit" });
}

function googleMapsOpenUrl(query) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}
function googleMapsDirUrl(lat, lon) {
  return `https://www.google.com/maps/dir/?api=1&destination=${lat},${lon}`;
}

async function callAnalyzeOnce(base64, mediaType, prompt) {
  // Calls our own backend proxy (functions/api/analyze.js) instead of api.anthropic.com directly —
  // outside the Claude artifact sandbox there is no ambient API key, so the real key must live
  // server-side only (set as a Cloudflare Pages secret), never in this client-side bundle.
  const response = await fetch("/api/analyze", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ base64, mediaType, prompt }),
  });

  const data = await response.json();

  if (!response.ok) {
    console.error("[analyzeSign] API error", response.status, data);
    throw new Error(data?.error?.message || `API error ${response.status}`);
  }
  if (data.stop_reason && data.stop_reason !== "end_turn" && data.stop_reason !== "stop_sequence") {
    console.warn("[analyzeSign] unusual stop_reason:", data.stop_reason);
  }

  const text = (data.content || []).map((b) => b.text || "").join("\n").trim();
  if (!text) {
    console.error("[analyzeSign] empty response body", data);
    throw new Error("empty response from model");
  }

  // pull out just the {...} block in case the model added any stray text/fences
  // around the JSON despite being asked not to
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1 || end < start) {
    console.error("[analyzeSign] no JSON object found in response:", text);
    throw new Error("response did not contain JSON");
  }
  const jsonSlice = text.slice(start, end + 1);

  try {
    return JSON.parse(jsonSlice);
  } catch (e) {
    console.error("[analyzeSign] JSON.parse failed on:", jsonSlice, e);
    throw new Error("could not parse model response as JSON");
  }
}

async function analyzeSign(base64, mediaType) {
  const prompt = `นี่คือรูปถ่ายป้ายประกาศขายหรือให้เช่าทรัพย์สิน (บ้าน ที่ดิน คอนโด อาคารพาณิชย์ ฯลฯ) ที่ติดอยู่หน้างานจริง
อ่านข้อความบนป้ายทั้งหมดแล้วแยกข้อมูลออกมาเป็น JSON เท่านั้น ห้ามมีข้อความอื่นใดนอกเหนือจาก JSON ห้ามใส่ backtick หรือ markdown ครอบ
ถ้าไม่มีข้อมูลในฟิลด์ใดให้ใส่ค่าเป็น null (ห้ามเดาข้อมูลที่ไม่ได้ปรากฏบนป้าย)

รูปแบบ JSON ที่ต้องการ:
{
  "propertyType": "หนึ่งใน: บ้านเดี่ยว, บ้านแฝด, ทาวน์เฮาส์, คอนโด, ที่ดิน, อาคารพาณิชย์, โกดัง/โรงงาน, อื่นๆ",
  "dealType": "หนึ่งใน: ขาย, เช่า, ขาย/เช่า",
  "price": "ราคาตามที่ระบุบนป้าย เป็นข้อความ เช่น 2.5 ล้านบาท",
  "phone": "เบอร์โทรที่ปรากฏ ถ้ามีหลายเบอร์คั่นด้วยจุลภาค",
  "contactName": "ชื่อผู้ติดต่อหรือชื่อสำนักงาน ถ้ามี",
  "sizeInfo": "ขนาดพื้นที่ เช่น ไร่ ตร.ว. ตร.ม. ถ้าระบุ",
  "addressHint": "ที่อยู่หรือจุดสังเกตที่ระบุบนป้าย ถ้ามี",
  "note": "ข้อมูลอื่นที่น่าสนใจบนป้าย เช่น จุดเด่น เลขที่โฉนด"
}`;

  // one automatic retry — most failures here are transient (network blip / rate limit),
  // not the AI actually being unable to read the sign
  try {
    return await callAnalyzeOnce(base64, mediaType, prompt);
  } catch (firstErr) {
    console.warn("[analyzeSign] first attempt failed, retrying once:", firstErr.message);
    await new Promise((r) => setTimeout(r, 1200));
    return await callAnalyzeOnce(base64, mediaType, prompt);
  }
}

// ---------- tile-based map (OpenStreetMap raster tiles, no API key, no iframe) ----------

const TILE_SIZE = 256;

function lon2tileX(lon, z) { return ((lon + 180) / 360) * Math.pow(2, z); }
function lat2tileY(lat, z) {
  const rad = (lat * Math.PI) / 180;
  return ((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2) * Math.pow(2, z);
}
function tileX2lon(x, z) { return (x / Math.pow(2, z)) * 360 - 180; }
function tileY2lat(y, z) {
  const n = Math.PI - (2 * Math.PI * y) / Math.pow(2, z);
  return (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
}

// Tiles are loaded via fetch()+blob instead of a plain <img src="..."> — a raw
// <img> load to an external tile server was consistently blocked in the Claude
// artifact preview (tried CARTO, OpenStreetMap, and Wikimedia — all rendered gray).
// fetch() is governed by a different browser permission path (connect-src) than
// direct image loads (img-src), and we already know fetch() works here (it's how
// the AI photo analysis and Smart Nearby OSM lookups work) — so this is a genuine
// second attempt at a real fix, not just another tile provider swap.
const tileBlobCache = new Map(); // url -> { status: 'loading'|'loaded'|'error', objectUrl? }

function useTileBlobs(tileUrls) {
  const [, bump] = useState(0);
  const key = tileUrls.join(",");
  useEffect(() => {
    let cancelled = false;
    tileUrls.forEach((url) => {
      if (tileBlobCache.has(url)) return;
      tileBlobCache.set(url, { status: "loading" });
      fetch(url)
        .then((res) => {
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          return res.blob();
        })
        .then((blob) => {
          const objectUrl = URL.createObjectURL(blob);
          tileBlobCache.set(url, { status: "loaded", objectUrl });
          if (!cancelled) bump((x) => x + 1);
        })
        .catch((err) => {
          console.warn(`[TileMap] tile fetch failed: ${url}`, err);
          tileBlobCache.set(url, { status: "error" });
          if (!cancelled) bump((x) => x + 1);
        });
    });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
}

function TileMap({ center, zoom, markers = [], onCenterChange, onZoomChange, height = "h-56", interactive = true, showControls = true, activeMarkerId, rounded = "rounded-2xl" }) {
  const containerRef = useRef(null);
  const [size, setSize] = useState({ w: 320, h: 220 });
  const dragRef = useRef(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver((entries) => {
      const r = entries[0].contentRect;
      if (r.width && r.height) setSize({ w: r.width, h: r.height });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const centerTX = lon2tileX(center.lon, zoom);
  const centerTY = lat2tileY(center.lat, zoom);
  const n = Math.pow(2, zoom);
  const baseX = Math.floor(centerTX);
  const baseY = Math.floor(centerTY);
  const colsHalf = Math.ceil(size.w / TILE_SIZE / 2) + 1;
  const rowsHalf = Math.ceil(size.h / TILE_SIZE / 2) + 1;

  const tiles = [];
  for (let dx = -colsHalf; dx <= colsHalf; dx++) {
    for (let dy = -rowsHalf; dy <= rowsHalf; dy++) {
      const tx = baseX + dx;
      const ty = baseY + dy;
      if (ty < 0 || ty >= n) continue;
      const wrappedX = ((tx % n) + n) % n;
      tiles.push({
        key: `${zoom}-${tx}-${ty}`,
        x: (tx - centerTX) * TILE_SIZE + size.w / 2,
        y: (ty - centerTY) * TILE_SIZE + size.h / 2,
        url: `https://maps.wikimedia.org/osm-intl/${zoom}/${wrappedX}/${ty}.png`,
      });
    }
  }

  const project = (lat, lon) => ({
    x: (lon2tileX(lon, zoom) - centerTX) * TILE_SIZE + size.w / 2,
    y: (lat2tileY(lat, zoom) - centerTY) * TILE_SIZE + size.h / 2,
  });

  useTileBlobs(tiles.map((t) => t.url));

  const onPointerDown = (e) => {
    if (!interactive) return;
    dragRef.current = { x: e.clientX, y: e.clientY, tx: centerTX, ty: centerTY };
    e.currentTarget.setPointerCapture?.(e.pointerId);
  };
  const onPointerMove = (e) => {
    if (!interactive || !dragRef.current) return;
    const dx = e.clientX - dragRef.current.x;
    const dy = e.clientY - dragRef.current.y;
    const newTX = dragRef.current.tx - dx / TILE_SIZE;
    const newTY = dragRef.current.ty - dy / TILE_SIZE;
    onCenterChange && onCenterChange({ lat: tileY2lat(newTY, zoom), lon: tileX2lon(newTX, zoom) });
  };
  const onPointerUp = (e) => {
    dragRef.current = null;
    try { e.currentTarget.releasePointerCapture?.(e.pointerId); } catch (err) {}
  };

  const homeMark = project(DEFAULT_CENTER.lat, DEFAULT_CENTER.lon);

  return (
    <div className={`relative w-full ${height} ${rounded} overflow-hidden bg-gray-200 select-none`}>
      <div
        ref={containerRef}
        className={`absolute inset-0 overflow-hidden touch-none ${interactive ? "cursor-grab active:cursor-grabbing" : ""}`}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerLeave={onPointerUp}
      >
        {tiles.map((t) => {
          const entry = tileBlobCache.get(t.url);
          if (entry?.status === "loaded") {
            return (
              <img
                key={t.key}
                src={entry.objectUrl}
                alt=""
                draggable={false}
                className="absolute pointer-events-none"
                style={{ left: t.x, top: t.y, width: TILE_SIZE, height: TILE_SIZE }}
              />
            );
          }
          // still loading, or failed — leave the gray background showing through
          // rather than an error icon or blank hole
          return null;
        })}

        {homeMark.x > -20 && homeMark.x < size.w + 20 && homeMark.y > -20 && homeMark.y < size.h + 20 && (
          <div className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none" style={{ left: homeMark.x, top: homeMark.y }}>
            <div className="w-3.5 h-3.5 rounded-full bg-blue-500 border-2 border-white shadow" />
          </div>
        )}

        {markers.map((m) => {
          const p = project(m.lat, m.lon);
          if (p.x < -30 || p.x > size.w + 30 || p.y < -30 || p.y > size.h + 30) return null;
          const active = activeMarkerId === m.id;
          return (
            <button
              key={m.id}
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => { e.stopPropagation(); m.onClick && m.onClick(); }}
              className="absolute -translate-x-1/2 -translate-y-full flex flex-col items-center"
              style={{ left: p.x, top: p.y }}
            >
              <div className={`w-7 h-7 rounded-full ${m.color} border-2 border-white shadow-md flex items-center justify-center transition-transform ${active ? "ring-2 ring-neutral-900 scale-110" : ""}`}>
                {m.Icon && <m.Icon className="w-3.5 h-3.5 text-white" strokeWidth={2.5} />}
              </div>
              <div className="w-1.5 h-1.5 rounded-full bg-neutral-900/50 -mt-0.5" />
            </button>
          );
        })}
      </div>

      {showControls && (
        <div className="absolute right-2 bottom-2 flex flex-col gap-1.5 z-10">
          <button onClick={() => onZoomChange && onZoomChange(Math.min(18, zoom + 1))} className="w-8 h-8 bg-white rounded-full shadow flex items-center justify-center text-neutral-700">
            <Plus className="w-4 h-4" />
          </button>
          <button onClick={() => onZoomChange && onZoomChange(Math.max(3, zoom - 1))} className="w-8 h-8 bg-white rounded-full shadow flex items-center justify-center text-neutral-700">
            <Minus className="w-4 h-4" />
          </button>
        </div>
      )}
      <div className="absolute left-1.5 bottom-1 text-[8px] text-neutral-600 bg-white/70 px-1 rounded pointer-events-none">Wikimedia maps | © OpenStreetMap contributors</div>
    </div>
  );
}

// ---------- real Google Maps JavaScript API integration (optional, requires a user-supplied API key) ----------
// There is no build-time env-var system in this runtime (no Vite/webpack), so the key is entered in-app
// (Settings, in the "More" menu) and kept in this browser's storage — it is never hard-coded here.

let gmapsLoadPromise = null;
function loadGoogleMapsScript(apiKey) {
  if (window.google?.maps) return Promise.resolve();
  if (gmapsLoadPromise) return gmapsLoadPromise;
  gmapsLoadPromise = new Promise((resolve, reject) => {
    const existing = document.getElementById("gmaps-sdk");
    if (existing) existing.remove();
    const script = document.createElement("script");
    script.id = "gmaps-sdk";
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(apiKey)}&v=weekly`;
    script.async = true;
    script.onload = () => (window.google?.maps ? resolve() : reject(new Error("google.maps unavailable after load")));
    script.onerror = () => reject(new Error("failed to load Google Maps script"));
    document.head.appendChild(script);
    setTimeout(() => reject(new Error("timeout loading Google Maps")), 9000);
  }).catch((err) => {
    gmapsLoadPromise = null; // allow retry
    throw err;
  });
  return gmapsLoadPromise;
}

function GoogleMapView({ apiKey, center, zoom, markers = [], userLocation, activeMarkerId, height = "h-56", onReady, onError, retryToken }) {
  const divRef = useRef(null);
  const mapRef = useRef(null);
  const markerObjsRef = useRef([]);
  const userMarkerRef = useRef(null);
  const [status, setStatus] = useState("loading"); // loading | ready | error

  useEffect(() => {
    let cancelled = false;
    setStatus("loading");
    loadGoogleMapsScript(apiKey)
      .then(() => {
        if (cancelled || !divRef.current) return;
        mapRef.current = new window.google.maps.Map(divRef.current, {
          center: { lat: center.lat, lng: center.lon },
          zoom,
          disableDefaultUI: true,
          gestureHandling: "greedy",
        });
        setStatus("ready");
        onReady && onReady();
      })
      .catch((err) => {
        if (cancelled) return;
        setStatus("error");
        onError && onError(err);
      });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [apiKey, retryToken]);

  // recenter when center/zoom props change externally
  useEffect(() => {
    if (mapRef.current && status === "ready") {
      mapRef.current.panTo({ lat: center.lat, lng: center.lon });
      mapRef.current.setZoom(zoom);
    }
  }, [center.lat, center.lon, zoom, status]);

  // sync property markers
  useEffect(() => {
    if (!mapRef.current || status !== "ready") return;
    markerObjsRef.current.forEach((m) => m.setMap(null));
    markerObjsRef.current = markers.map((m) => {
      const marker = new window.google.maps.Marker({
        position: { lat: m.lat, lng: m.lon },
        map: mapRef.current,
        icon: {
          path: window.google.maps.SymbolPath.CIRCLE,
          scale: m.id === activeMarkerId ? 11 : 9,
          fillColor: m.hexColor,
          fillOpacity: 1,
          strokeColor: "#ffffff",
          strokeWeight: 2,
        },
      });
      marker.addListener("click", () => m.onClick && m.onClick());
      return marker;
    });
  }, [markers, status, activeMarkerId]);

  // sync current-location marker
  useEffect(() => {
    if (!mapRef.current || status !== "ready") return;
    if (userMarkerRef.current) { userMarkerRef.current.setMap(null); userMarkerRef.current = null; }
    if (userLocation) {
      userMarkerRef.current = new window.google.maps.Marker({
        position: { lat: userLocation.lat, lng: userLocation.lon },
        map: mapRef.current,
        icon: { path: window.google.maps.SymbolPath.CIRCLE, scale: 7, fillColor: "#3b82f6", fillOpacity: 1, strokeColor: "#ffffff", strokeWeight: 2 },
      });
    }
  }, [userLocation, status]);

  return (
    <div className={`relative w-full ${height} rounded-2xl overflow-hidden bg-gray-200`}>
      <div ref={divRef} className="absolute inset-0" />
      {status === "loading" && (
        <div className="absolute inset-0 bg-gray-100 flex items-center justify-center gap-2 text-gray-400 text-xs font-medium">
          <Loader2 className="w-4 h-4 animate-spin" /> กำลังโหลด Google Maps...
        </div>
      )}
    </div>
  );
}

// wraps GoogleMapView with the required fallback states so a bad/missing key or a failed
// load can never blank the page — falls back to the always-working tile map instead.
function SmartMapView(props) {
  const { apiKey, onRetry, retryToken, fallback: Fallback, fallbackProps, ...rest } = props;
  const [gError, setGError] = useState(false);

  if (!apiKey) {
    return (
      <div className="relative">
        <Fallback {...fallbackProps} />
        <div className="absolute top-2 left-2 right-2 bg-neutral-900/85 text-white text-[11px] font-medium rounded-full px-3 py-1.5 flex items-center justify-between gap-2">
          <span>ยังไม่ได้ตั้งค่า Google Maps API</span>
        </div>
      </div>
    );
  }

  if (gError) {
    return (
      <div className={`relative w-full ${rest.height || "h-56"} rounded-2xl overflow-hidden bg-gray-100 flex flex-col items-center justify-center gap-2 text-center px-6`}>
        <AlertTriangle className="w-6 h-6 text-red-500" />
        <div className="text-sm font-bold text-neutral-800">ไม่สามารถโหลด Google Maps ได้</div>
        <button
          onClick={() => { setGError(false); onRetry && onRetry(); }}
          className="mt-1 bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-full px-4 py-2"
        >
          ลองใหม่
        </button>
      </div>
    );
  }

  return <GoogleMapView {...rest} apiKey={apiKey} retryToken={retryToken} onError={() => setGError(true)} />;
}



function FieldRow({ icon: Icon, label, value, mono = false }) {
  if (!value) return null;
  return (
    <div className="flex items-start gap-3 py-2.5 border-b border-gray-100 last:border-b-0">
      <Icon className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" strokeWidth={2.5} />
      <div className="min-w-0 flex-1">
        <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400">{label}</div>
        <div className={`text-sm text-gray-800 break-words ${mono ? "font-mono" : "font-medium"}`}>{value}</div>
      </div>
    </div>
  );
}

function Chip({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide border-2 transition-colors ${
        active ? "bg-neutral-900 border-neutral-900 text-amber-400" : "bg-white border-gray-200 text-gray-500"
      }`}
    >
      {children}
    </button>
  );
}

function TextField({ label, value, onChange, mono }) {
  return (
    <div>
      <label className="text-[10px] font-bold uppercase text-gray-400">{label}</label>
      <input
        type="text"
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        className={`mt-1 w-full text-sm border border-gray-200 rounded-md px-2 py-2 bg-gray-50 font-medium ${mono ? "font-mono" : ""}`}
      />
    </div>
  );
}

function Toast({ message }) {
  if (!message) return null;
  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[70] max-w-[85%]">
      <div className="bg-neutral-900 text-white text-xs font-medium px-4 py-2.5 rounded-full shadow-lg whitespace-nowrap overflow-hidden text-ellipsis">
        {message}
      </div>
    </div>
  );
}

function TypeDot({ type, className = "w-2.5 h-2.5" }) {
  return <span className={`${className} rounded-full inline-block ${TYPE_COLOR[type] || "bg-neutral-400"}`} />;
}

// ---------- header ----------

function AppHeader({ tab, onBell, onProfile, onBack }) {
  const titles = {
    home: null, map: "Smart Map", capture: "เก็บป้ายใหม่", catalog: "แคตตาล็อกทรัพย์สิน",
    nearby: "Smart Nearby", safety: "Safety", compare: "Compare", workspace: "Workspace", export: "Export", import: "นำเข้าข้อมูล",
  };
  const showBack = ["nearby", "safety", "compare", "workspace", "export", "import"].includes(tab);
  return (
    <div className="bg-white px-4 pt-5 pb-4 flex items-center justify-between border-b border-gray-100">
      <div className="flex items-center gap-2">
        {showBack && (
          <button onClick={onBack} className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center shrink-0">
            <ChevronLeft className="w-4.5 h-4.5 text-neutral-700" />
          </button>
        )}
        <div>
          {tab === "home" ? (
            <>
              <div className="text-2xl font-black tracking-tight text-neutral-900">
                FIELDMATE <span className="text-amber-400">AI</span>
              </div>
              <div className="text-[11px] text-gray-400 font-medium mt-0.5">Smart Field Survey · Smarter Valuation</div>
            </>
          ) : (
            <div className="text-lg font-black text-neutral-900">{titles[tab]}</div>
          )}
        </div>
      </div>
      <div className="flex items-center gap-3">
        <button onClick={onBell} className="relative w-9 h-9 rounded-full bg-gray-50 flex items-center justify-center">
          <Bell className="w-4.5 h-4.5 text-neutral-700" />
          <span className="absolute -top-1 -right-1 bg-amber-400 text-neutral-900 text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-white">3</span>
        </button>
        <button onClick={onProfile} className="w-9 h-9 rounded-full bg-gray-300 flex items-center justify-center overflow-hidden">
          <User className="w-5 h-5 text-gray-600" />
        </button>
      </div>
    </div>
  );
}

// ---------- pin callout (quick preview on marker / row tap) ----------

function PinCallout({ listing, onClose, onViewDetail, onEdit, userLocation }) {
  if (!listing) return null;
  const coords = listingCoords(listing);
  const perUnit = pricePerUnit(listing.price, listing.sizeInfo);
  const dist = userLocation ? formatDistance(haversineKm(userLocation, coords)) : null;
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 flex justify-center px-3 pb-24">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden animate-[fadeIn_0.15s_ease-out]">
        <div className="flex">
          <img src={listing.image} alt="" className="w-24 h-24 object-cover shrink-0" />
          <div className="flex-1 min-w-0 p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 min-w-0">
                <TypeDot type={listing.propertyType} />
                <span className="text-[10px] font-black uppercase tracking-wide text-gray-500 truncate">{listing.propertyType || "ไม่ระบุ"}</span>
                {listing.dealType && <span className="text-[9px] font-bold bg-neutral-900 text-amber-400 px-1.5 py-0.5 rounded shrink-0">{listing.dealType}</span>}
              </div>
              <button onClick={onClose} className="w-6 h-6 rounded-full bg-gray-50 flex items-center justify-center shrink-0">
                <X className="w-3.5 h-3.5 text-gray-500" />
              </button>
            </div>
            <div className="font-black text-neutral-900 truncate">{listing.price || "ไม่ระบุราคา"}</div>
            <div className="text-[11px] text-gray-500 truncate">
              {listing.sizeInfo || "ไม่ระบุขนาด"}
              {perUnit ? ` · ~${perUnit.toLocaleString()} บาท/หน่วย` : ""}
              {dist ? ` · ห่าง ${dist}` : ""}
            </div>
            <div className="text-[11px] text-gray-500 font-mono truncate flex items-center gap-1 mt-0.5">
              <Phone className="w-3 h-3 shrink-0" /> {listing.phone || "—"}
            </div>
          </div>
        </div>
        <div className="px-3 pb-2 text-[10px] text-gray-400 space-y-0.5">
          <div>เก็บข้อมูลเมื่อ {timeAgo(listing.createdAt)} · ผู้เก็บข้อมูล: เจ้าหน้าที่ภาคสนาม</div>
          <div>แหล่งที่มา: ถ่ายภาพหน้างานด้วย FieldMate AI</div>
        </div>
        <div className="grid grid-cols-3 gap-2 p-3 pt-1">
          <button onClick={() => onViewDetail(listing)} className="bg-neutral-900 text-amber-400 text-[11px] font-black uppercase tracking-wide rounded-full py-2">
            ดูรายละเอียด
          </button>
          <a
            href={googleMapsDirUrl(coords.lat, coords.lon)}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-amber-400 text-neutral-900 text-[11px] font-black uppercase tracking-wide rounded-full py-2 flex items-center justify-center gap-1"
          >
            <Navigation className="w-3 h-3" /> นำทาง
          </a>
          <button onClick={() => onEdit(listing)} className="bg-gray-50 border border-gray-200 text-neutral-700 text-[11px] font-black uppercase tracking-wide rounded-full py-2">
            แก้ไข
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------- home tab ----------

function HomeTab({ listings, incidents, onNavigate, onToast, onOpenListing }) {
  const [locating, setLocating] = useState(false);
  const [zoom, setZoom] = useState(15);
  const [center, setCenter] = useState(DEFAULT_CENTER);

  const total = listings.length;
  const countHouse = listings.filter((l) => ["บ้านเดี่ยว", "บ้านแฝด", "ทาวน์เฮาส์"].includes(l.propertyType)).length;
  const countLand = listings.filter((l) => l.propertyType === "ที่ดิน").length;
  const countCondo = listings.filter((l) => ["คอนโด", "อาคารพาณิชย์"].includes(l.propertyType)).length;

  const markers = listings.slice(0, 12).map((l) => {
    const c = listingCoords(l);
    const Icon = TYPE_ICON[l.propertyType] || Tag;
    return { id: l.id, lat: c.lat, lon: c.lon, color: TYPE_COLOR[l.propertyType] || "bg-neutral-400", Icon, onClick: () => onOpenListing(l) };
  });

  const handleLocate = () => {
    setLocating(true);
    setTimeout(() => {
      setLocating(false);
      setCenter(DEFAULT_CENTER);
      onToast("อัปเดตตำแหน่งปัจจุบันแล้ว");
    }, 700);
  };

  return (
    <div className="px-4 pt-4 pb-28 space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm px-4 py-3 flex items-center gap-3">
        <MapPin className="w-5 h-5 text-amber-500 shrink-0" strokeWidth={2.5} />
        <div className="flex-1 min-w-0">
          <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">ตำแหน่งปัจจุบัน</div>
          <div className="text-sm font-semibold text-neutral-800 truncate">{DEFAULT_LABEL}</div>
        </div>
        <button onClick={handleLocate} className="w-9 h-9 rounded-full bg-gray-50 flex items-center justify-center shrink-0">
          {locating ? <Loader2 className="w-4 h-4 animate-spin text-amber-500" /> : <LocateFixed className="w-4 h-4 text-neutral-700" />}
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
        <div className="flex items-center justify-between mb-0.5">
          <div className="text-lg font-black text-neutral-900 tracking-tight">SMART MAP</div>
          <button onClick={() => onNavigate("map")} className="text-[11px] font-bold text-amber-600 flex items-center gap-0.5">
            เต็มจอ <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="text-xs text-gray-400 font-medium mb-3">ดูข้อมูลป้ายประกาศขายบนแผนที่รอบตัวคุณแบบเรียลไทม์</div>
        <TileMap center={center} zoom={zoom} onCenterChange={setCenter} onZoomChange={setZoom} markers={markers} height="h-52" interactive={true} />
        <button
          onClick={() => onNavigate("map")}
          className="mt-3 bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-full pl-4 pr-2 py-2 flex items-center gap-2 active:scale-[0.97] transition-transform"
        >
          ดูบนแผนที่
          <span className="w-5 h-5 rounded-full bg-amber-400 text-neutral-900 flex items-center justify-center">
            <ChevronRight className="w-3.5 h-3.5" />
          </span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden flex flex-col">
          <div className="p-4 pb-2">
            <div className="font-black text-neutral-900 leading-tight">AI CAMERA</div>
            <div className="text-[11px] text-gray-400 font-medium mt-1">ถ่ายป้าย ประมวลผลด้วย AI อ่านข้อมูลอัตโนมัติ</div>
          </div>
          <div className="flex-1 flex items-center justify-center py-3">
            <div className="w-16 h-16 rounded-2xl bg-neutral-900 flex items-center justify-center relative">
              <Camera className="w-8 h-8 text-white" strokeWidth={1.75} />
              <span className="absolute -bottom-1 -right-1 bg-amber-400 text-neutral-900 text-[9px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">AI</span>
            </div>
          </div>
          <button onClick={() => onNavigate("capture")} className="bg-amber-400 text-neutral-900 text-xs font-black uppercase tracking-wide py-2.5 flex items-center justify-center gap-1.5 active:brightness-95">
            เก็บป้ายใหม่ <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden flex flex-col">
          <div className="p-4 pb-2">
            <div className="font-black text-neutral-900 leading-tight">DATA CATALOG</div>
            <div className="text-[11px] text-gray-400 font-medium mt-1">ค้นหา กรอง และจัดการข้อมูลป้ายประกาศขาย</div>
          </div>
          <div className="flex-1 flex items-center justify-center py-3">
            <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center relative">
              <Database className="w-8 h-8 text-neutral-700" strokeWidth={1.75} />
              <span className="absolute -bottom-1 -right-1 bg-neutral-900 text-white text-[9px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">{total}</span>
            </div>
          </div>
          <button onClick={() => onNavigate("catalog")} className="bg-amber-400 text-neutral-900 text-xs font-black uppercase tracking-wide py-2.5 flex items-center justify-center gap-1.5 active:brightness-95">
            ดูข้อมูลทั้งหมด <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
        <button onClick={() => onNavigate("nearby")} className="w-full flex items-center justify-between mb-1">
          <div className="text-left">
            <div className="font-black text-neutral-900">SMART NEARBY</div>
            <div className="text-[11px] text-gray-400 font-medium">ป้ายขายและข้อมูลสำคัญรอบตัวคุณ</div>
          </div>
          <ChevronRight className="w-4 h-4 text-gray-300" />
        </button>
        <div className="grid grid-cols-4 gap-2 mt-3">
          <StatCell icon={Tag} value={total} label="ป้ายขายใกล้เคียง" />
          <StatCell icon={HomeIcon} value={countHouse} label="บ้าน/ทาวน์เฮาส์" />
          <StatCell icon={Trees} value={countLand} label="ที่ดิน" />
          <StatCell icon={Building2} value={countCondo} label="คอนโด/อาคารพาณิชย์" />
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
        <button onClick={() => onNavigate("safety")} className="w-full flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-500" strokeWidth={2.25} />
            <div className="text-left">
              <div className="font-black text-neutral-900 text-sm">SAFETY ALERT</div>
              <div className="text-[11px] text-gray-400 font-medium">มีจุดที่ควรระวังในบริเวณใกล้เคียง ({incidents.length})</div>
            </div>
          </div>
          <span className="text-[11px] font-bold text-amber-600 flex items-center gap-0.5 shrink-0">
            ดูทั้งหมด <ChevronRight className="w-3.5 h-3.5" />
          </span>
        </button>
        {incidents.length === 0 ? (
          <div className="text-xs text-gray-400 text-center py-3">ยังไม่มีรายงานเหตุการณ์ในบริเวณนี้</div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {incidents.slice(0, 2).map((inc) => {
              const Icon = INCIDENT_ICON[inc.type] || AlertTriangle;
              return (
                <button key={inc.id} onClick={() => onNavigate("safety")} className="bg-gray-50 rounded-xl px-3 py-2.5 flex items-center gap-2 text-left">
                  <Icon className="w-5 h-5 text-neutral-700 shrink-0" />
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-neutral-800 truncate">{inc.type}</div>
                    <div className="text-[10px] text-gray-400">{inc.distanceM} เมตร</div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCell({ icon: Icon, value, label }) {
  return (
    <div className="flex flex-col items-center text-center bg-gray-50 rounded-xl py-2.5 px-1">
      <Icon className="w-4 h-4 text-amber-500 mb-1" strokeWidth={2.25} />
      <div className="text-base font-black text-neutral-900 leading-none">{value}</div>
      <div className="text-[9px] text-gray-400 font-medium mt-1 leading-tight">{label}</div>
    </div>
  );
}

// ---------- map tab (Smart Map) ----------

function GMapsKeyModal({ currentKey, onSave, onClear, onClose }) {
  const [value, setValue] = useState(currentKey || "");
  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-neutral-900/60" onClick={onClose}>
      <div className="w-full max-w-md bg-white rounded-t-3xl p-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <span className="font-black text-neutral-900">ตั้งค่า Google Maps API Key</span>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center">
            <X className="w-4 h-4 text-gray-600" />
          </button>
        </div>
        <p className="text-xs text-gray-500 mb-3">
          ใส่ Google Maps JavaScript API Key ของคุณเองเพื่อใช้แผนที่ Google จริงในแอปนี้ คีย์จะถูกเก็บไว้ในเครื่องนี้เท่านั้น
          ถ้าไม่ใส่ แอปจะใช้แผนที่ทางเลือกที่ฝังอยู่ในแอปอยู่แล้วแทน (ยังคงลาก/ซูมและปักหมุดได้ตามปกติ)
        </p>
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="AIzaSy..."
          className="w-full text-sm border border-gray-200 rounded-md px-3 py-2.5 bg-gray-50 font-mono mb-3"
        />
        <div className="flex gap-2">
          <button
            onClick={() => { if (value.trim()) { onSave(value.trim()); onClose(); } }}
            className="flex-1 bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-full py-3"
          >
            บันทึก
          </button>
          {currentKey && (
            <button onClick={() => { onClear(); onClose(); }} className="flex-1 bg-gray-50 border border-gray-200 text-red-600 text-xs font-black uppercase tracking-wide rounded-full py-3">
              ลบคีย์
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function MapTab({ listings, onOpenListing, onNavigate, onToast, onEditListing }) {
  const [zoom, setZoom] = useState(15);
  const [center, setCenter] = useState(DEFAULT_CENTER);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("ทั้งหมด");
  const [activeId, setActiveId] = useState(null);

  const [gmapsKey, setGmapsKey] = useState(null);
  const [keyChecked, setKeyChecked] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [retryToken, setRetryToken] = useState(0);

  const [userLocation, setUserLocation] = useState(null);
  const [locationError, setLocationError] = useState(false);
  const [nearMe, setNearMe] = useState(false);

  const searchRef = useRef(null);
  const listRef = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const r = await window.storage.get(GMAPS_KEY_STORAGE);
        if (r && r.value) setGmapsKey(r.value);
      } catch (e) {}
      setKeyChecked(true);
    })();
  }, []);

  useEffect(() => {
    if (!navigator.geolocation) { setLocationError(true); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => { setUserLocation({ lat: pos.coords.latitude, lon: pos.coords.longitude }); setLocationError(false); },
      () => setLocationError(true),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  }, []);

  const saveKey = async (key) => {
    try { await window.storage.set(GMAPS_KEY_STORAGE, key); } catch (e) {}
    setGmapsKey(key);
    setRetryToken((t) => t + 1);
    onToast("บันทึก Google Maps API Key แล้ว");
  };
  const clearKey = async () => {
    try { await window.storage.delete(GMAPS_KEY_STORAGE); } catch (e) {}
    setGmapsKey(null);
    onToast("ลบคีย์แล้ว ใช้แผนที่ทางเลือกที่ฝังในแอปแทน");
  };

  let filtered = listings.filter((l) => {
    if (filter !== "ทั้งหมด") {
      if (filter === "อื่นๆ") {
        if (["ที่ดิน", "บ้านเดี่ยว", "ทาวน์เฮาส์", "คอนโด"].includes(l.propertyType)) return false;
      } else if (l.propertyType !== filter) return false;
    }
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return [l.propertyType, l.price, l.phone, l.location, l.note, l.contactName].filter(Boolean).some((f) => f.toLowerCase().includes(q));
  });

  if (nearMe && userLocation) {
    filtered = [...filtered].sort((a, b) => haversineKm(userLocation, listingCoords(a)) - haversineKm(userLocation, listingCoords(b)));
  }

  const markers = filtered.map((l) => {
    const c = listingCoords(l);
    const Icon = TYPE_ICON[l.propertyType] || Tag;
    return {
      id: l.id,
      lat: c.lat,
      lon: c.lon,
      color: TYPE_COLOR[l.propertyType] || "bg-neutral-400",
      hexColor: TYPE_HEX[l.propertyType] || "#a3a3a3",
      Icon,
      onClick: () => setActiveId(l.id),
    };
  });

  const activeListing = filtered.find((l) => l.id === activeId) || null;

  const focusListing = (l) => {
    setActiveId(l.id);
    setCenter(listingCoords(l));
    setZoom(16);
  };

  const locateCurrent = () => {
    setNearMe(false);
    setCenter(userLocation || DEFAULT_CENTER);
    setZoom(15);
    setActiveId(null);
    if (!userLocation) onToast("ไม่สามารถระบุตำแหน่งปัจจุบันได้");
  };

  const handleNearMe = () => {
    if (!userLocation) { onToast("ไม่สามารถระบุตำแหน่งปัจจุบันได้"); return; }
    setNearMe(true);
    setCenter(userLocation);
    setZoom(15);
    setActiveId(null);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    const guess = geocodeGuess(query);
    if (guess) {
      setCenter(guess);
      setZoom(15);
    } else if (query.trim()) {
      onToast("ค้นหาจากรายการป้ายที่บันทึกไว้ด้านล่าง");
    }
  };

  const legendCounts = LEGEND_TYPES.map((t) => ({ type: t, count: listings.filter((l) => l.propertyType === t).length }));
  const otherCount = listings.filter((l) => !LEGEND_TYPES.includes(l.propertyType)).length;

  return (
    <div className="pb-28">
      <div className="px-4 pt-4 space-y-3">
        <form onSubmit={handleSearch} className="bg-white border border-gray-200 rounded-full flex items-center px-3 py-2.5 shadow-sm">
          <Search className="w-4 h-4 text-gray-400 mr-2 shrink-0" />
          <input
            ref={searchRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ค้นหาโครงการ ถนน แขวง เขต ประเภททรัพย์"
            className="flex-1 text-sm bg-transparent outline-none placeholder:text-gray-400 min-w-0"
          />
        </form>

        <div className="flex gap-2 overflow-x-auto pb-0.5">
          {MAP_FILTERS.map((f) => (
            <Chip key={f} active={filter === f} onClick={() => setFilter(f)}>{f}</Chip>
          ))}
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3">
          <div className="relative">
            {keyChecked && (
              <SmartMapView
                apiKey={gmapsKey}
                fallback={TileMap}
                fallbackProps={{ center, zoom, onCenterChange: setCenter, onZoomChange: setZoom, markers, height: "h-64", interactive: true, activeMarkerId: activeId, showControls: false }}
                center={center}
                zoom={zoom}
                markers={markers}
                userLocation={userLocation}
                activeMarkerId={activeId}
                height="h-64"
                retryToken={retryToken}
                onRetry={() => setRetryToken((t) => t + 1)}
              />
            )}

            <div className="absolute right-2 bottom-2 flex flex-col gap-1.5 z-10">
              <button onClick={() => setZoom((z) => Math.min(18, z + 1))} className="w-8 h-8 bg-white rounded-full shadow flex items-center justify-center text-neutral-700">
                <Plus className="w-4 h-4" />
              </button>
              <button onClick={() => setZoom((z) => Math.max(3, z - 1))} className="w-8 h-8 bg-white rounded-full shadow flex items-center justify-center text-neutral-700">
                <Minus className="w-4 h-4" />
              </button>
            </div>

            {locationError && (
              <div className="absolute top-2 left-2 right-2 bg-neutral-900/85 text-white text-[11px] font-medium rounded-full px-3 py-1.5 text-center">
                ไม่สามารถระบุตำแหน่งปัจจุบันได้
              </div>
            )}
          </div>

          <div className="flex items-center gap-x-4 gap-y-2 flex-wrap mt-3">
            <button onClick={locateCurrent} className="flex items-center gap-1.5 text-xs font-bold text-neutral-700">
              <LocateFixed className="w-3.5 h-3.5 text-amber-500" /> ตำแหน่งปัจจุบัน
            </button>
            <button onClick={() => searchRef.current?.focus()} className="flex items-center gap-1.5 text-xs font-bold text-neutral-700">
              <Search className="w-3.5 h-3.5 text-amber-500" /> ค้นหา
            </button>
            <button onClick={() => listRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })} className="flex items-center gap-1.5 text-xs font-bold text-neutral-700">
              <ClipboardList className="w-3.5 h-3.5 text-amber-500" /> รายการประกาศ
            </button>
            <button onClick={() => setSettingsOpen(true)} className="flex items-center gap-1.5 text-xs font-bold text-amber-600 ml-auto">
              {gmapsKey ? "แก้ไข Google Maps API" : "ตั้งค่า Google Maps"}
            </button>
          </div>

          <button onClick={handleNearMe} className="mt-3 w-full bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-full py-3 flex items-center justify-center gap-2">
            <LocateFixed className="w-4 h-4" /> ค้นหาประกาศใกล้ฉัน
          </button>
        </div>

        {/* legend */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center gap-1.5 mb-2.5">
            <Layers className="w-4 h-4 text-amber-500" />
            <div className="font-black text-neutral-900 text-sm">ประเภททรัพย์สิน</div>
          </div>
          <div className="grid grid-cols-2 gap-x-3 gap-y-2">
            {legendCounts.map((it) => (
              <div key={it.type} className="flex items-center gap-2">
                <TypeDot type={it.type} />
                <span className="text-xs text-neutral-700 flex-1 truncate">{it.type}</span>
                <span className="text-xs font-bold text-neutral-900">{it.count}</span>
              </div>
            ))}
            <div className="flex items-center gap-2">
              <TypeDot type="อื่นๆ" />
              <span className="text-xs text-neutral-700 flex-1 truncate">อื่นๆ</span>
              <span className="text-xs font-bold text-neutral-900">{otherCount}</span>
            </div>
          </div>
        </div>
      </div>

      <div ref={listRef} className="px-4 mt-4 flex items-center justify-between scroll-mt-4">
        <div className="font-black text-neutral-900">{nearMe ? "ทรัพย์ใกล้คุณ (เรียงตามระยะทาง)" : "รายการทรัพย์ใกล้คุณ"}</div>
        <span className="text-xs font-bold text-gray-400">{filtered.length} รายการ</span>
      </div>

      <div className="px-4 mt-2 space-y-2.5">
        {filtered.length === 0 && (
          <div className="flex flex-col items-center text-center py-12 gap-3">
            <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center">
              <MapIcon className="w-6 h-6 text-gray-400" />
            </div>
            <div className="text-sm text-gray-400 max-w-[220px]">
              {listings.length === 0 ? "ยังไม่มีป้ายที่บันทึกไว้ ลองถ่ายป้ายแรกของคุณ" : "ไม่พบป้ายที่ตรงกับตัวกรอง"}
            </div>
            {listings.length === 0 && (
              <button onClick={() => onNavigate("capture")} className="bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-full px-4 py-2">
                เก็บป้ายใหม่
              </button>
            )}
          </div>
        )}

        {filtered.map((l) => {
          const Icon = TYPE_ICON[l.propertyType] || Tag;
          const active = activeId === l.id;
          const dist = userLocation ? formatDistance(haversineKm(userLocation, listingCoords(l))) : null;
          return (
            <div
              key={l.id}
              onClick={() => focusListing(l)}
              className={`w-full bg-white rounded-xl border shadow-sm px-3 py-2.5 flex items-center gap-3 text-left cursor-pointer transition-colors ${active ? "border-amber-400 ring-1 ring-amber-300" : "border-gray-100"}`}
            >
              <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${TYPE_COLOR[l.propertyType] || "bg-neutral-400"}`}>
                <Icon className="w-4.5 h-4.5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-bold text-neutral-800 truncate">{l.price || l.propertyType || "ไม่ระบุ"}</div>
                <div className="text-xs text-gray-400 truncate flex items-center gap-1">
                  <MapPin className="w-3 h-3 shrink-0" /> {l.location || "ไม่ระบุตำแหน่ง"}
                  {dist && <span className="text-amber-600 font-semibold shrink-0">· {dist}</span>}
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-300 shrink-0" />
            </div>
          );
        })}
      </div>

      {activeListing && (
        <PinCallout
          listing={activeListing}
          onClose={() => setActiveId(null)}
          onViewDetail={(l) => { onOpenListing(l); }}
          onEdit={(l) => { onEditListing(l); }}
          userLocation={userLocation}
        />
      )}

      {settingsOpen && <GMapsKeyModal currentKey={gmapsKey} onSave={saveKey} onClear={clearKey} onClose={() => setSettingsOpen(false)} />}
    </div>
  );
}

// ---------- smart nearby tab ----------

function NearbyTab({ listings, favoriteIds, onToggleFavorite, onOpenListing, initialCategory }) {
  const [radiusKm, setRadiusKm] = useState(0.5);
  const [category, setCategory] = useState(initialCategory || "all");
  const [typeFilters, setTypeFilters] = useState({ "ที่ดิน": true, "บ้านเดี่ยว": true, "ทาวน์เฮาส์": true, "คอนโด": true, "อาคารพาณิชย์": false });
  const [userLocation, setUserLocation] = useState(null);
  const [locationError, setLocationError] = useState(false);
  const [sortBy, setSortBy] = useState("distance");
  const [poiState, setPoiState] = useState({}); // { [categoryKey]: { items, loading, isFallback } }

  useEffect(() => {
    if (!navigator.geolocation) { setLocationError(true); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => setUserLocation({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
      () => setLocationError(true),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  }, []);

  const origin = userLocation || DEFAULT_CENTER;
  const originKey = `${origin.lat.toFixed(4)},${origin.lon.toFixed(4)}`;
  const radiusText = radiusKm < 1 ? `${Math.round(radiusKm * 1000)} ม.` : `${radiusKm} กม.`;

  // fetch real POI data from OpenStreetMap for every category whenever location/radius changes,
  // falling back to the illustrative generator per-category if the live request fails
  useEffect(() => {
    let cancelled = false;
    setPoiState((prev) => {
      const next = { ...prev };
      POI_CATEGORIES.forEach((cat) => { next[cat.key] = { items: prev[cat.key]?.items || [], loading: true, isFallback: prev[cat.key]?.isFallback ?? false }; });
      return next;
    });

    POI_CATEGORIES.forEach(async (cat) => {
      try {
        const raw = await fetchOverpassPOIs(cat, origin, radiusKm);
        if (cancelled) return;
        const items = raw
          .map((p) => ({ ...p, dist: haversineKm(origin, { lat: p.lat, lon: p.lon }) }))
          .filter((p) => p.dist <= radiusKm)
          .sort((a, b) => a.dist - b.dist);
        setPoiState((prev) => ({ ...prev, [cat.key]: { items, loading: false, isFallback: false } }));
      } catch (e) {
        if (cancelled) return;
        const items = generatePOIs(origin, radiusKm, cat)
          .map((p) => ({ ...p, dist: haversineKm(origin, { lat: p.lat, lon: p.lon }) }))
          .filter((p) => p.dist <= radiusKm);
        setPoiState((prev) => ({ ...prev, [cat.key]: { items, loading: false, isFallback: true } }));
      }
    });

    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [originKey, radiusKm]);

  const withDistance = listings.map((l) => ({ l, dist: haversineKm(origin, listingCoords(l)) }));
  const propsFiltered = withDistance
    .filter(({ dist }) => dist <= radiusKm)
    .filter(({ l }) => (Object.keys(typeFilters).includes(l.propertyType) ? typeFilters[l.propertyType] : true))
    .sort((a, b) => (sortBy === "distance" ? a.dist - b.dist : (parseNumber(a.l.price) || 0) - (parseNumber(b.l.price) || 0)));

  const categorySummaries = [
    ...POI_CATEGORIES.map((cat) => {
      const st = poiState[cat.key];
      const items = st?.items || [];
      return { key: cat.key, label: cat.label, icon: cat.icon, color: cat.color, count: items.length, nearest: items.length ? items[0].dist : null, loading: st?.loading };
    }),
    { key: "housing", label: "ป้ายขาย/ทรัพย์", icon: Tag, color: "bg-emerald-500", count: propsFiltered.length, nearest: propsFiltered.length ? propsFiltered[0].dist : null, loading: false },
  ];

  const activeCat = POI_CATEGORIES.find((c) => c.key === category);
  const activeItems = activeCat ? (poiState[category]?.items || []) : [];
  const activeLoading = activeCat ? !!poiState[category]?.loading : false;
  const activeIsFallback = activeCat ? !!poiState[category]?.isFallback : false;

  let markers = [];
  if (category === "all") {
    markers = [
      ...propsFiltered.map(({ l }) => { const c = listingCoords(l); const Icon = TYPE_ICON[l.propertyType] || Tag; return { id: l.id, lat: c.lat, lon: c.lon, color: "bg-emerald-500", Icon, onClick: () => onOpenListing(l) }; }),
      ...POI_CATEGORIES.flatMap((cat) => (poiState[cat.key]?.items || []).map((p) => ({ id: p.id, lat: p.lat, lon: p.lon, color: cat.color, Icon: cat.icon }))),
    ];
  } else if (category === "housing") {
    markers = propsFiltered.map(({ l }) => { const c = listingCoords(l); const Icon = TYPE_ICON[l.propertyType] || Tag; return { id: l.id, lat: c.lat, lon: c.lon, color: TYPE_COLOR[l.propertyType] || "bg-neutral-400", Icon, onClick: () => onOpenListing(l) }; });
  } else if (activeCat) {
    markers = activeItems.map((p) => ({ id: p.id, lat: p.lat, lon: p.lon, color: activeCat.color, Icon: activeCat.icon }));
  }

  const toggleType = (t) => setTypeFilters((prev) => ({ ...prev, [t]: !prev[t] }));

  return (
    <div className="px-4 pt-4 pb-28 space-y-4">
      <div>
        <div className="text-lg font-black text-neutral-900 tracking-tight flex items-center gap-1.5">
          <LocateFixed className="w-5 h-5 text-amber-500" /> SMART NEARBY
        </div>
        <div className="text-xs text-gray-400 font-medium mt-0.5">รู้จักพื้นที่รอบตัวคุณ ภายในไม่กี่วินาที</div>
      </div>

      {locationError && (
        <div className="bg-neutral-900 text-white text-xs font-medium rounded-full px-4 py-2 text-center">
          ไม่สามารถระบุตำแหน่งปัจจุบันได้ — ใช้ตำแหน่งเริ่มต้นแทน
        </div>
      )}

      <div className="bg-neutral-900 rounded-2xl p-3">
        <div className="text-[10px] font-bold uppercase tracking-wide text-gray-400 mb-2 px-1">ระยะรอบตัวคุณ</div>
        <div className="grid grid-cols-4 gap-1.5">
          {NEARBY_RADII.map((r) => (
            <button key={r.km} onClick={() => setRadiusKm(r.km)} className={`text-xs font-black rounded-full py-2 ${radiusKm === r.km ? "bg-amber-400 text-neutral-900" : "bg-white/10 text-white"}`}>
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* category quick-select row */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        <button
          onClick={() => setCategory("all")}
          className={`shrink-0 flex flex-col items-center gap-1 w-16 py-2 rounded-xl border-2 ${category === "all" ? "border-amber-400 bg-amber-50" : "border-gray-100 bg-white"}`}
        >
          <Grid3x3 className="w-4 h-4 text-neutral-700" />
          <span className="text-[9px] font-bold text-neutral-600">ทั้งหมด</span>
        </button>
        {categorySummaries.map((cs) => (
          <button
            key={cs.key}
            onClick={() => setCategory(cs.key)}
            className={`shrink-0 flex flex-col items-center gap-1 w-16 py-2 rounded-xl border-2 ${category === cs.key ? "border-amber-400 bg-amber-50" : "border-gray-100 bg-white"}`}
          >
            <div className={`w-6 h-6 rounded-full ${cs.color} flex items-center justify-center relative`}>
              {cs.loading ? <Loader2 className="w-3 h-3 text-white animate-spin" /> : <cs.icon className="w-3.5 h-3.5 text-white" />}
            </div>
            <span className="text-[9px] font-bold text-neutral-600 text-center leading-tight">{cs.label}</span>
            <span className="text-[8px] text-gray-400">{cs.loading ? "..." : `${cs.count} แห่ง`}</span>
          </button>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3">
        <TileMap center={origin} zoom={15} markers={markers} height="h-56" interactive={true} showControls={false} />
      </div>

      {category === "all" && (
        <div>
          <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-2">สรุปข้อมูลรอบตัว (ภายใน {radiusText})</div>
          <div className="grid grid-cols-2 gap-2">
            {categorySummaries.map((cs) => (
              <button key={cs.key} onClick={() => setCategory(cs.key)} className="bg-white border border-gray-100 rounded-xl p-3 flex items-center gap-2.5 text-left">
                <div className={`w-9 h-9 rounded-full ${cs.color} flex items-center justify-center shrink-0`}>
                  {cs.loading ? <Loader2 className="w-4 h-4 text-white animate-spin" /> : <cs.icon className="w-4.5 h-4.5 text-white" />}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-black text-neutral-900">{cs.loading ? "กำลังโหลด..." : `${cs.count} แห่ง`}</div>
                  <div className="text-[10px] text-gray-400 truncate">{cs.label}{cs.nearest != null ? ` · ใกล้สุด ${formatDistance(cs.nearest)}` : ""}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {category === "housing" && (
        <>
          <div className="grid grid-cols-4 gap-2">
            <StatCell icon={Tag} value={propsFiltered.length} label="ป้ายขายใกล้เคียง" />
            <StatCell icon={HomeIcon} value={propsFiltered.filter(({ l }) => ["บ้านเดี่ยว", "บ้านแฝด", "ทาวน์เฮาส์"].includes(l.propertyType)).length} label="บ้าน/ทาวน์เฮาส์" />
            <StatCell icon={Trees} value={propsFiltered.filter(({ l }) => l.propertyType === "ที่ดิน").length} label="ที่ดิน" />
            <StatCell icon={Building2} value={propsFiltered.filter(({ l }) => ["คอนโด", "อาคารพาณิชย์"].includes(l.propertyType)).length} label="คอนโด/อาคารพาณิชย์" />
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-2">ประเภททรัพย์</div>
            <div className="flex flex-wrap gap-2">
              {Object.keys(typeFilters).map((t) => (
                <button key={t} onClick={() => toggleType(t)} className={`flex items-center gap-1.5 text-xs font-bold rounded-full px-3 py-1.5 border-2 ${typeFilters[t] ? "bg-neutral-900 border-neutral-900 text-amber-400" : "bg-white border-gray-200 text-gray-400"}`}>
                  <TypeDot type={t} className="w-2 h-2" /> {t}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="font-black text-neutral-900 text-sm">พบ {propsFiltered.length} รายการ ภายในระยะ {radiusText}</div>
            <button onClick={() => setSortBy((s) => (s === "distance" ? "price" : "distance"))} className="flex items-center gap-1 text-xs font-bold text-amber-600 shrink-0">
              {sortBy === "distance" ? "ระยะใกล้สุด" : "ราคาต่ำสุด"} <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </div>

          {propsFiltered.length === 0 ? (
            <div className="flex flex-col items-center text-center py-12 gap-3">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center">
                <LocateFixed className="w-6 h-6 text-gray-400" />
              </div>
              <div className="text-sm text-gray-400 max-w-[220px]">ไม่พบทรัพย์ในระยะที่เลือก ลองขยายระยะค้นหาดู</div>
            </div>
          ) : (
            <div className="space-y-2.5">
              {propsFiltered.map(({ l, dist }, i) => {
                const fav = favoriteIds.includes(l.id);
                return (
                  <button key={l.id} onClick={() => onOpenListing(l)} className="w-full text-left bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden flex active:scale-[0.98] transition-transform">
                    <div className="relative w-20 h-20 shrink-0">
                      <img src={l.image} alt="" className="w-full h-full object-cover" />
                      <span className="absolute top-1 left-1 bg-amber-400 text-neutral-900 text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">{i + 1}</span>
                    </div>
                    <div className="flex-1 min-w-0 p-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1 min-w-0">
                          <TypeDot type={l.propertyType} className="w-2 h-2" />
                          <span className="text-[10px] font-bold text-gray-400 truncate">{l.propertyType || "ไม่ระบุ"}</span>
                        </div>
                        <button onClick={(e) => { e.stopPropagation(); onToggleFavorite(l.id); }} className="shrink-0">
                          <Star className={`w-4 h-4 ${fav ? "text-amber-400 fill-amber-400" : "text-gray-300"}`} />
                        </button>
                      </div>
                      <div className="text-sm font-black text-neutral-800 truncate">{l.price || "ไม่ระบุราคา"}</div>
                      <div className="text-[10px] text-gray-400 truncate flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 shrink-0" /> {l.location || "ไม่ระบุตำแหน่ง"} <span className="text-amber-600 font-semibold">· {formatDistance(dist)}</span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </>
      )}

      {activeCat && (
        <>
          <div className="font-black text-neutral-900 text-sm">{activeCat.label}ใกล้คุณ ({activeLoading ? "..." : activeItems.length} แห่ง)</div>

          {activeLoading ? (
            <div className="flex items-center justify-center py-12 text-gray-400 gap-2">
              <Loader2 className="w-5 h-5 animate-spin" /> กำลังค้นหาข้อมูลจริงจาก OpenStreetMap...
            </div>
          ) : activeItems.length === 0 ? (
            <div className="flex flex-col items-center text-center py-12 gap-3">
              <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center">
                <activeCat.icon className="w-6 h-6 text-gray-400" />
              </div>
              <div className="text-sm text-gray-400 max-w-[220px]">ไม่พบ{activeCat.label}ในระยะที่เลือก ลองขยายระยะค้นหาดู</div>
            </div>
          ) : (
            <div className="space-y-2.5">
              {activeItems.map((p) => (
                <div key={p.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3 flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl ${activeCat.color} flex items-center justify-center shrink-0`}>
                    <activeCat.icon className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-neutral-800 truncate">{p.name}</div>
                    <div className="flex items-center gap-1 text-xs text-gray-500 mt-0.5">
                      {p.rating != null && (
                        <>
                          <Star className="w-3 h-3 text-amber-400 fill-amber-400" /> {p.rating.toFixed(1)} ({p.reviews})
                          <span className="text-gray-300">·</span>
                        </>
                      )}
                      <MapPin className="w-3 h-3" /> {formatDistance(p.dist)}
                    </div>
                  </div>
                  <a
                    href={googleMapsDirUrl(p.lat, p.lon)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="shrink-0 flex items-center gap-1 bg-neutral-900 text-amber-400 text-[11px] font-black uppercase tracking-wide rounded-full px-3 py-2"
                  >
                    <Navigation className="w-3.5 h-3.5" /> นำทาง
                  </a>
                </div>
              ))}
            </div>
          )}

          {!activeLoading && (
            activeIsFallback ? (
              <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div className="text-[11px] text-amber-700">เชื่อมต่อข้อมูลจริงจาก OpenStreetMap ไม่สำเร็จในขณะนี้ (เครือข่ายหรือเซิร์ฟเวอร์ไม่ตอบสนอง) กำลังแสดงข้อมูลตัวอย่างแทน</div>
              </div>
            ) : (
              <div className="flex items-start gap-2 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-[11px] text-emerald-700">เชื่อมต่อข้อมูลสถานที่จริงจาก OpenStreetMap แล้ว (คะแนนรีวิวยังไม่มีในข้อมูลแหล่งนี้)</div>
              </div>
            )
          )}
        </>
      )}
    </div>
  );
}

// ---------- safety tab ----------

function ReportIncidentModal({ onClose, onSubmit }) {
  const [type, setType] = useState(INCIDENT_TYPES[0]);
  const [note, setNote] = useState("");
  const [distanceM, setDistanceM] = useState("100");

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-neutral-900/60" onClick={onClose}>
      <div className="w-full max-w-md bg-white rounded-t-3xl p-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <span className="font-black text-neutral-900">รายงานเหตุการณ์ใหม่</span>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center">
            <X className="w-4 h-4 text-gray-600" />
          </button>
        </div>
        <div className="flex flex-wrap gap-2 mb-3">
          {INCIDENT_TYPES.map((t) => {
            const Icon = INCIDENT_ICON[t];
            return (
              <button key={t} onClick={() => setType(t)} className={`flex items-center gap-1.5 text-xs font-bold rounded-full px-3 py-2 border-2 ${type === t ? "bg-neutral-900 border-neutral-900 text-amber-400" : "bg-white border-gray-200 text-gray-500"}`}>
                <Icon className="w-3.5 h-3.5" /> {t}
              </button>
            );
          })}
        </div>
        <TextField label="ระยะห่างโดยประมาณ (เมตร)" value={distanceM} onChange={setDistanceM} mono />
        <div className="mt-3">
          <label className="text-[10px] font-bold uppercase text-gray-400">รายละเอียดเพิ่มเติม</label>
          <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} className="mt-1 w-full text-sm border border-gray-200 rounded-md px-2 py-2 bg-gray-50 font-medium resize-none" />
        </div>
        <button
          onClick={() => onSubmit({ type, note, distanceM: parseInt(distanceM, 10) || 0 })}
          className="w-full mt-4 bg-neutral-900 text-amber-400 font-black uppercase tracking-wide text-sm rounded-full py-3"
        >
          ส่งรายงาน
        </button>
      </div>
    </div>
  );
}

function SafetyTab({ incidents, onAddIncident, onConfirmIncident }) {
  const [modalOpen, setModalOpen] = useState(false);

  const summaryByType = INCIDENT_TYPES.map((t) => {
    const list = incidents.filter((i) => i.type === t);
    const nearest = list.length ? Math.min(...list.map((i) => i.distanceM)) : null;
    return { type: t, count: list.length, nearest };
  });

  return (
    <div className="px-4 pt-4 pb-28 space-y-4">
      <div>
        <div className="text-lg font-black text-neutral-900 tracking-tight flex items-center gap-1.5">
          <ShieldCheck className="w-5 h-5 text-amber-500" /> SAFETY
        </div>
        <div className="text-xs text-gray-400 font-medium mt-0.5">รายงานและแจ้งเตือนความปลอดภัยในพื้นที่</div>
      </div>

      {incidents.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-3 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />
          <div className="text-sm font-bold text-red-700">เหตุการณ์ใกล้เคียง {incidents.length} รายการ</div>
        </div>
      )}

      <div className="grid grid-cols-4 gap-2">
        {summaryByType.map((s) => {
          const Icon = INCIDENT_ICON[s.type];
          return (
            <div key={s.type} className="flex flex-col items-center text-center bg-white border border-gray-100 rounded-xl py-2.5 px-1">
              <Icon className="w-4 h-4 text-amber-500 mb-1" strokeWidth={2.25} />
              <div className="text-xs font-black text-neutral-900 leading-none">{s.nearest != null ? `${s.nearest} ม.` : "-"}</div>
              <div className="text-[9px] text-gray-400 font-medium mt-1 leading-tight">{s.type}</div>
            </div>
          );
        })}
      </div>

      <div className="flex items-center justify-between">
        <div className="font-black text-neutral-900">รายงานเหตุการณ์</div>
        <button onClick={() => setModalOpen(true)} className="flex items-center gap-1 bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-full px-3 py-1.5">
          <Plus className="w-3.5 h-3.5" /> รายงานใหม่
        </button>
      </div>

      {incidents.length === 0 ? (
        <div className="flex flex-col items-center text-center py-12 gap-3">
          <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 text-gray-400" />
          </div>
          <div className="text-sm text-gray-400 max-w-[220px]">ยังไม่มีรายงานเหตุการณ์ในพื้นที่นี้</div>
        </div>
      ) : (
        <div className="space-y-2.5">
          {incidents.map((inc) => {
            const Icon = INCIDENT_ICON[inc.type] || AlertTriangle;
            return (
              <div key={inc.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3 flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-amber-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <div className="text-sm font-bold text-neutral-800">{inc.type}</div>
                    <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full shrink-0 ${inc.status === "ยืนยันแล้ว" ? "bg-emerald-100 text-emerald-700" : "bg-gray-100 text-gray-500"}`}>
                      {inc.status}
                    </span>
                  </div>
                  {inc.note && <div className="text-xs text-gray-500 mt-0.5">{inc.note}</div>}
                  <div className="text-[10px] text-gray-400 mt-1">{inc.distanceM} เมตร · {timeAgo(inc.createdAt)}</div>
                  {inc.status !== "ยืนยันแล้ว" && (
                    <button onClick={() => onConfirmIncident(inc.id)} className="mt-2 text-[11px] font-bold text-amber-600">ยืนยันเหตุการณ์นี้</button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modalOpen && <ReportIncidentModal onClose={() => setModalOpen(false)} onSubmit={(data) => { onAddIncident(data); setModalOpen(false); }} />}
    </div>
  );
}

// ---------- bulk import (Excel/CSV + separate photo files) ----------

function ImportPage({ onImported, onBack, onToast }) {
  const [step, setStep] = useState(1);
  const [fileName, setFileName] = useState("");
  const [headers, setHeaders] = useState([]);
  const [parsedRows, setParsedRows] = useState([]);
  const [fieldMapping, setFieldMapping] = useState({});
  const [photoFiles, setPhotoFiles] = useState([]);
  const [photoMap, setPhotoMap] = useState({});
  const [matchMode, setMatchMode] = useState("filename"); // filename | order | none
  const [loadingPhotos, setLoadingPhotos] = useState(false);
  const [importing, setImporting] = useState(false);
  const excelInputRef = useRef(null);
  const photoInputRef = useRef(null);

  const handleExcelFile = async (file) => {
    if (!file) return;
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json(sheet, { defval: "" });
      if (json.length === 0) { onToast("ไม่พบข้อมูลในไฟล์นี้"); return; }
      const hdrs = Object.keys(json[0]);
      setFileName(file.name);
      setHeaders(hdrs);
      setParsedRows(json);
      setFieldMapping(guessColumnMapping(hdrs));
      setStep(2);
    } catch (e) {
      onToast("อ่านไฟล์ไม่สำเร็จ ตรวจสอบว่าเป็นไฟล์ Excel/CSV ที่ถูกต้อง");
    }
  };

  const handlePhotoFiles = async (fileList) => {
    const files = Array.from(fileList || []);
    if (files.length === 0) return;
    setPhotoFiles(files);
    setLoadingPhotos(true);
    const map = {};
    for (const f of files) {
      try { map[f.name] = await resizeImage(f); } catch (e) {}
    }
    setPhotoMap(map);
    setLoadingPhotos(false);
    onToast(`โหลดรูปภาพแล้ว ${files.length} ไฟล์`);
  };

  const setMap = (key, value) => setFieldMapping((prev) => ({ ...prev, [key]: value }));

  const buildListings = () =>
    parsedRows.map((row, i) => {
      const get = (key) => (fieldMapping[key] ? String(row[fieldMapping[key]] ?? "").trim() : "");
      let image = PLACEHOLDER_IMAGE;
      if (matchMode === "filename" && fieldMapping.imageFilenameCol) {
        const fname = String(row[fieldMapping.imageFilenameCol] ?? "").trim();
        if (fname && photoMap[fname]) image = photoMap[fname];
      } else if (matchMode === "order" && photoFiles[i]) {
        image = photoMap[photoFiles[i].name] || PLACEHOLDER_IMAGE;
      }
      return {
        id: uid(),
        createdAt: new Date().toISOString(),
        image,
        aiAnalyzed: false,
        imported: true,
        propertyType: get("propertyType"),
        dealType: get("dealType"),
        price: get("price"),
        phone: get("phone"),
        contactName: get("contactName"),
        sizeInfo: get("sizeInfo"),
        location: get("location"),
        note: get("note"),
      };
    });

  const matchedPhotoCount = () => {
    const listings = buildListings();
    return listings.filter((l) => l.image !== PLACEHOLDER_IMAGE).length;
  };

  const handleConfirmImport = async () => {
    setImporting(true);
    try {
      const newListings = buildListings();
      const idx = await storageGet("listings-index");
      const ids = idx ? JSON.parse(idx.value) : [];
      for (const l of newListings) {
        const { image, ...meta } = l;
        await storageSet(`listing:${l.id}`, JSON.stringify(meta));
        // matched photo is optional here — if it fails to save, the listing's
        // data is already safe, it'll just show the placeholder image
        if (image && image !== PLACEHOLDER_IMAGE) {
          try { await storageSet(`listing-image:${l.id}`, image); } catch (e) { console.warn("[ImportPage] image save failed for", l.id, e); }
        }
        ids.unshift(l.id);
      }
      await storageSet("listings-index", JSON.stringify(ids));
      onImported(newListings);
      onToast(`นำเข้าข้อมูล ${newListings.length} รายการเรียบร้อยแล้ว`);
      onBack();
    } catch (e) {
      console.error("[ImportPage] handleConfirmImport failed:", e);
      onToast("นำเข้าข้อมูลไม่สำเร็จ กรุณาลองอีกครั้ง");
    } finally {
      setImporting(false);
    }
  };

  const preview = step === 3 ? buildListings() : [];

  return (
    <div className="px-4 pt-4 pb-28 space-y-4">
      <div>
        <div className="text-lg font-black text-neutral-900 tracking-tight flex items-center gap-1.5">
          <FileSpreadsheet className="w-5 h-5 text-emerald-600" /> นำเข้าข้อมูล
        </div>
        <div className="text-xs text-gray-400 font-medium mt-0.5">นำเข้าไฟล์ Excel/CSV ป้ายประกาศขายที่เคยเก็บไว้ พร้อมรูปภาพ</div>
      </div>

      {/* step indicator */}
      <div className="flex items-center gap-2">
        {[1, 2, 3].map((s) => (
          <div key={s} className={`flex-1 h-1.5 rounded-full ${step >= s ? "bg-amber-400" : "bg-gray-200"}`} />
        ))}
      </div>

      {step === 1 && (
        <>
          <button
            onClick={() => excelInputRef.current?.click()}
            className="w-full aspect-[4/3] rounded-2xl border-4 border-dashed border-gray-200 bg-white flex flex-col items-center justify-center gap-3 active:scale-[0.98] transition-transform"
          >
            <div className="w-16 h-16 rounded-full bg-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-500/30">
              <FileSpreadsheet className="w-8 h-8 text-white" strokeWidth={2} />
            </div>
            <div className="text-center px-6">
              <div className="font-black uppercase tracking-wide text-neutral-800">เลือกไฟล์ Excel หรือ CSV</div>
              <div className="text-xs text-gray-400 mt-1">รองรับ .xlsx .xls .csv — แถวแรกต้องเป็นหัวตาราง</div>
            </div>
          </button>
          <input ref={excelInputRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={(e) => handleExcelFile(e.target.files?.[0])} />

          <div className="flex items-start gap-2 bg-blue-50 border border-blue-100 rounded-xl px-3 py-2.5">
            <Info className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
            <div className="text-[11px] text-blue-700">
              รูปภาพที่ฝังอยู่ในไฟล์ Excel จะดึงออกมาอัตโนมัติไม่ได้ — ขั้นตอนถัดไปจะให้อัปโหลดไฟล์รูปแยกต่างหาก แล้วระบบจะจับคู่ให้
            </div>
          </div>
        </>
      )}

      {step === 2 && (
        <>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className="flex items-center gap-2 mb-1">
              <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
              <div className="text-sm font-bold text-neutral-800 truncate">{fileName}</div>
            </div>
            <div className="text-xs text-gray-400">พบข้อมูล {parsedRows.length} แถว, {headers.length} คอลัมน์</div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-3">จับคู่คอลัมน์กับข้อมูลในแอป</div>
            <div className="space-y-3">
              {IMPORT_FIELDS.map((f) => (
                <div key={f.key}>
                  <label className="text-[10px] font-bold uppercase text-gray-400">{f.label}</label>
                  <select
                    value={fieldMapping[f.key] || ""}
                    onChange={(e) => setMap(f.key, e.target.value)}
                    className="mt-1 w-full text-sm border border-gray-200 rounded-md px-2 py-2 bg-gray-50 font-medium"
                  >
                    <option value="">— ไม่ใช้ —</option>
                    {headers.map((h) => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-2">รูปภาพ (แยกจากไฟล์ Excel)</div>
            <button
              onClick={() => photoInputRef.current?.click()}
              disabled={loadingPhotos}
              className="w-full flex items-center justify-center gap-2 bg-gray-50 border border-gray-200 rounded-full py-2.5 text-sm font-black uppercase tracking-wide text-neutral-700 disabled:opacity-60"
            >
              {loadingPhotos ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImagePlus className="w-4.5 h-4.5" />}
              {photoFiles.length > 0 ? `เลือกแล้ว ${photoFiles.length} รูป (แตะเพื่อเลือกใหม่)` : "เลือกรูปภาพ (เลือกได้หลายไฟล์)"}
            </button>
            <input ref={photoInputRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => handlePhotoFiles(e.target.files)} />

            {photoFiles.length > 0 && (
              <div className="mt-3 flex gap-2">
                <button onClick={() => setMatchMode("filename")} className={`flex-1 text-xs font-bold rounded-full py-2 border-2 ${matchMode === "filename" ? "bg-neutral-900 border-neutral-900 text-amber-400" : "bg-white border-gray-200 text-gray-500"}`}>
                  จับคู่ตามชื่อไฟล์
                </button>
                <button onClick={() => setMatchMode("order")} className={`flex-1 text-xs font-bold rounded-full py-2 border-2 ${matchMode === "order" ? "bg-neutral-900 border-neutral-900 text-amber-400" : "bg-white border-gray-200 text-gray-500"}`}>
                  จับคู่ตามลำดับแถว
                </button>
                <button onClick={() => setMatchMode("none")} className={`flex-1 text-xs font-bold rounded-full py-2 border-2 ${matchMode === "none" ? "bg-neutral-900 border-neutral-900 text-amber-400" : "bg-white border-gray-200 text-gray-500"}`}>
                  ไม่ใส่รูป
                </button>
              </div>
            )}
            {matchMode === "filename" && !fieldMapping.imageFilenameCol && (
              <div className="text-[11px] text-amber-600 mt-2">ยังไม่ได้เลือกคอลัมน์ "ชื่อไฟล์รูปภาพ" ด้านบน — จะไม่สามารถจับคู่ตามชื่อไฟล์ได้</div>
            )}
          </div>

          <div className="flex gap-2">
            <button onClick={() => setStep(1)} className="flex-1 bg-white border border-gray-200 text-neutral-700 text-xs font-black uppercase tracking-wide rounded-full py-3">ย้อนกลับ</button>
            <button onClick={() => setStep(3)} className="flex-1 bg-amber-400 text-neutral-900 text-xs font-black uppercase tracking-wide rounded-full py-3">ดูตัวอย่าง</button>
          </div>
        </>
      )}

      {step === 3 && (
        <>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
              <ListChecks className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <div className="text-sm font-black text-neutral-900">พร้อมนำเข้า {preview.length} รายการ</div>
              <div className="text-[11px] text-gray-400">มีรูปภาพจับคู่แล้ว {matchedPhotoCount()} / {preview.length} รายการ</div>
            </div>
          </div>

          <div className="space-y-2">
            {preview.slice(0, 8).map((l, i) => (
              <div key={l.id} className="bg-white rounded-xl border border-gray-100 shadow-sm px-3 py-2.5 flex items-center gap-3">
                <img src={l.image} alt="" className="w-12 h-12 rounded-lg object-cover shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-bold text-neutral-800 truncate">{l.price || l.propertyType || `แถวที่ ${i + 1}`}</div>
                  <div className="text-[10px] text-gray-400 truncate">{l.location || "ไม่ระบุทำเล"}</div>
                </div>
              </div>
            ))}
            {preview.length > 8 && <div className="text-center text-xs text-gray-400 py-1">และอีก {preview.length - 8} รายการ</div>}
          </div>

          <div className="flex gap-2">
            <button onClick={() => setStep(2)} className="flex-1 bg-white border border-gray-200 text-neutral-700 text-xs font-black uppercase tracking-wide rounded-full py-3">แก้ไขการจับคู่</button>
            <button
              onClick={handleConfirmImport}
              disabled={importing}
              className="flex-1 bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-full py-3 flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {importing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              นำเข้าข้อมูล {preview.length} รายการ
            </button>
          </div>
        </>
      )}
    </div>
  );
}

// ---------- capture tab ----------

function CaptureTab({ onSaved, goToTab, onToast }) {
  const [pending, setPending] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzedOk, setAnalyzedOk] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [draft, setDraft] = useState(null);
  const [saving, setSaving] = useState(false);
  const [locating, setLocating] = useState(false);
  const inputRef = useRef(null);
  const galleryInputRef = useRef(null);

  const reset = () => {
    setPending(null);
    setAnalyzing(false);
    setAnalyzedOk(false);
    setErrorMsg("");
    setDraft(null);
  };

  const handleFile = async (file) => {
    if (!file) return;
    reset();
    try {
      const dataUrl = await resizeImage(file);
      const base64 = dataUrl.split(",")[1];
      setPending({ dataUrl, base64, mediaType: "image/jpeg" });
      setAnalyzing(true);
      try {
        const result = await analyzeSign(base64, "image/jpeg");
        const parsedSize = parseRaiNganWah(result.sizeInfo);
        setDraft({
          propertyType: result.propertyType || "",
          dealType: result.dealType || "",
          price: result.price || "",
          phone: result.phone || "",
          contactName: result.contactName || "",
          sizeInfo: parsedSize ? formatRaiNganWah(parsedSize.rai, parsedSize.ngan, parsedSize.wah) || result.sizeInfo || "" : result.sizeInfo || "",
          rai: parsedSize?.rai || "", ngan: parsedSize?.ngan || "", wah: parsedSize?.wah || "",
          lat: null, lon: null,
          location: result.addressHint || "",
          note: result.note || "",
        });
        setAnalyzedOk(true);
      } catch (e) {
        console.error("[CaptureTab] analyzeSign failed:", e);
        setErrorMsg(`AI อ่านป้ายไม่สำเร็จ (${e.message || "ข้อผิดพลาดไม่ทราบสาเหตุ"}) กรุณากรอกข้อมูลด้วยตนเองด้านล่าง หรือลองถ่ายใหม่อีกครั้ง`);
        setDraft({ propertyType: "", dealType: "", price: "", phone: "", contactName: "", sizeInfo: "", rai: "", ngan: "", wah: "", lat: null, lon: null, location: "", note: "" });
      }
    } catch (e) {
      setErrorMsg("ไม่สามารถโหลดรูปภาพได้ ลองใหม่อีกครั้ง");
    } finally {
      setAnalyzing(false);
    }
  };

  const handleUseLocation = () => {
    if (!navigator.geolocation) { onToast("อุปกรณ์นี้ไม่รองรับ GPS"); return; }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false);
        setDraft((d) => (d ? { ...d, lat: pos.coords.latitude, lon: pos.coords.longitude } : d));
        onToast("บันทึกพิกัดปัจจุบันแล้ว");
      },
      () => { setLocating(false); onToast("ไม่สามารถระบุตำแหน่งปัจจุบันได้"); },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const updateLandSize = (field, value) => {
    setDraft((d) => {
      if (!d) return d;
      const next = { ...d, [field]: value };
      const formatted = formatRaiNganWah(next.rai, next.ngan, next.wah);
      return { ...next, sizeInfo: formatted || next.sizeInfo };
    });
  };

  const handleSave = async () => {
    if (!pending || !draft) return;
    setSaving(true);
    setErrorMsg("");
    const id = uid();
    const meta = { id, createdAt: new Date().toISOString(), aiAnalyzed: analyzedOk, ...draft };
    let finalImage = PLACEHOLDER_IMAGE;
    let imageSaveWarning = false;
    try {
      // save the (small) text data and the (potentially large) photo as two separate
      // storage writes. If the photo write is what's actually failing, the listing's
      // data still gets saved instead of losing everything.
      await storageSet(`listing:${id}`, JSON.stringify(meta));

      try {
        await storageSet(`listing-image:${id}`, pending.dataUrl);
        finalImage = pending.dataUrl;
      } catch (imgErr) {
        console.warn("[CaptureTab] full-size image save failed, retrying smaller:", imgErr);
        try {
          const smaller = await recompressDataUrl(pending.dataUrl, 420, 0.4);
          await storageSet(`listing-image:${id}`, smaller);
          finalImage = smaller;
        } catch (imgErr2) {
          console.error("[CaptureTab] image save failed even after shrinking — keeping the listing without a stored photo:", imgErr2);
          imageSaveWarning = true;
        }
      }

      let ids = [];
      try {
        const idx = await storageGet("listings-index");
        ids = idx ? JSON.parse(idx.value) : [];
      } catch (e) {
        // don't silently wipe the index on a read failure — that would hide every
        // existing listing from the catalog even though its data is still there
        console.error("[CaptureTab] could not read listings-index, aborting save:", e);
        throw new Error("อ่านรายการเดิมไม่สำเร็จ ยกเลิกเพื่อป้องกันข้อมูลเดิมหาย");
      }
      ids.unshift(id);
      await storageSet("listings-index", JSON.stringify(ids));

      const listing = { ...meta, image: finalImage };
      onSaved(listing);
      reset();
      onToast(imageSaveWarning ? "บันทึกข้อมูลสำเร็จ แต่รูปภาพบันทึกไม่สำเร็จ (จะแสดงเป็นรูปว่างชั่วคราว)" : "บันทึกทรัพย์สินเรียบร้อยแล้ว");
      goToTab("catalog");
    } catch (e) {
      console.error("[CaptureTab] handleSave failed:", e);
      setErrorMsg(`บันทึกไม่สำเร็จ (${e.message || "ข้อผิดพลาดไม่ทราบสาเหตุ"}) กรุณาลองอีกครั้ง`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-4 pb-28">
      {!pending && (
        <>
          <button onClick={() => inputRef.current?.click()} className="w-full aspect-[4/5] rounded-2xl border-4 border-dashed border-gray-200 bg-white flex flex-col items-center justify-center gap-3 active:scale-[0.98] transition-transform">
            <div className="w-20 h-20 rounded-full bg-amber-400 flex items-center justify-center shadow-lg shadow-amber-400/30">
              <Camera className="w-9 h-9 text-neutral-900" strokeWidth={2.5} />
            </div>
            <div className="text-center px-6">
              <div className="font-black uppercase tracking-wide text-neutral-800">แตะเพื่อถ่ายรูปป้าย</div>
              <div className="text-xs text-gray-400 mt-1">AI จะอ่านราคา เบอร์โทร และรายละเอียดให้อัตโนมัติ</div>
            </div>
          </button>
          <button
            onClick={() => galleryInputRef.current?.click()}
            className="w-full mt-3 flex items-center justify-center gap-2 bg-white border border-gray-200 rounded-full py-3 text-sm font-black uppercase tracking-wide text-neutral-700 active:scale-[0.98] transition-transform"
          >
            <ImagePlus className="w-4.5 h-4.5" /> อัปโหลดรูปจากคลังภาพ
          </button>
          <input ref={inputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />
          <input ref={galleryInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />
        </>
      )}

      {pending && (
        <div>
          <div className="rounded-2xl overflow-hidden border border-gray-100 bg-white shadow-sm">
            <div className="relative">
              <img src={pending.dataUrl} alt="ป้ายที่ถ่าย" className="w-full object-cover max-h-72" />
              {analyzing && (
                <div className="absolute inset-0 bg-neutral-900/70 flex flex-col items-center justify-center gap-2">
                  <Loader2 className="w-8 h-8 text-amber-400 animate-spin" />
                  <div className="text-amber-400 text-xs font-bold uppercase tracking-widest">กำลังอ่านป้าย...</div>
                </div>
              )}
              {analyzedOk && !analyzing && (
                <div className="absolute top-2 right-2 bg-emerald-600 text-white text-[10px] font-black uppercase tracking-wider px-2 py-1 rounded-full flex items-center gap-1 shadow">
                  <CheckCircle2 className="w-3 h-3" /> AI Scanned
                </div>
              )}
            </div>
            <div className="px-3 py-2 flex items-center justify-between">
              <span className="text-[10px] font-mono text-gray-400">{new Date().toLocaleString("th-TH")}</span>
              <button onClick={reset} className="flex items-center gap-1 text-xs font-bold uppercase text-gray-500">
                <RotateCcw className="w-3.5 h-3.5" /> ถ่ายใหม่
              </button>
            </div>
          </div>

          {errorMsg && (
            <div className="mt-3 flex items-start gap-2 bg-red-50 border border-red-200 text-red-700 text-xs rounded-md px-3 py-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {draft && !analyzing && (
            <div className="mt-4 bg-white rounded-2xl border border-gray-100 p-4 space-y-3">
              <div className="text-[10px] font-black uppercase tracking-widest text-gray-400">ตรวจสอบและแก้ไขข้อมูล</div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold uppercase text-gray-400">ประเภททรัพย์</label>
                  <select value={draft.propertyType} onChange={(e) => setDraft({ ...draft, propertyType: e.target.value })} className="mt-1 w-full text-sm border border-gray-200 rounded-md px-2 py-2 bg-gray-50 font-medium">
                    <option value="">เลือก</option>
                    {PROPERTY_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase text-gray-400">ประเภทการขาย</label>
                  <select value={draft.dealType} onChange={(e) => setDraft({ ...draft, dealType: e.target.value })} className="mt-1 w-full text-sm border border-gray-200 rounded-md px-2 py-2 bg-gray-50 font-medium">
                    <option value="">เลือก</option>
                    {DEAL_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>
              <TextField label="ราคา" value={draft.price} onChange={(v) => setDraft({ ...draft, price: v })} />
              <TextField label="เบอร์โทร" value={draft.phone} onChange={(v) => setDraft({ ...draft, phone: v })} mono />
              <TextField label="ผู้ติดต่อ / สำนักงาน" value={draft.contactName} onChange={(v) => setDraft({ ...draft, contactName: v })} />

              {draft.propertyType === "ที่ดิน" ? (
                <div>
                  <label className="text-[10px] font-bold uppercase text-gray-400">ขนาดที่ดิน (ไร่ - งาน - ตร.ว.)</label>
                  <div className="grid grid-cols-3 gap-2 mt-1">
                    <input type="number" min="0" inputMode="decimal" value={draft.rai} onChange={(e) => updateLandSize("rai", e.target.value)} placeholder="ไร่" className="text-sm border border-gray-200 rounded-md px-2 py-2 bg-gray-50 font-medium text-center" />
                    <input type="number" min="0" inputMode="decimal" value={draft.ngan} onChange={(e) => updateLandSize("ngan", e.target.value)} placeholder="งาน" className="text-sm border border-gray-200 rounded-md px-2 py-2 bg-gray-50 font-medium text-center" />
                    <input type="number" min="0" inputMode="decimal" value={draft.wah} onChange={(e) => updateLandSize("wah", e.target.value)} placeholder="ตร.ว." className="text-sm border border-gray-200 rounded-md px-2 py-2 bg-gray-50 font-medium text-center" />
                  </div>
                  {draft.sizeInfo && <div className="text-[11px] text-gray-400 mt-1">{draft.sizeInfo}</div>}
                </div>
              ) : (
                <TextField label="ขนาดพื้นที่ (เช่น ตร.ม.)" value={draft.sizeInfo} onChange={(v) => setDraft({ ...draft, sizeInfo: v })} />
              )}

              <div>
                <label className="text-[10px] font-bold uppercase text-gray-400">พิกัด GPS</label>
                <div className="mt-1 flex items-center gap-2">
                  <div className="flex-1 text-xs border border-gray-200 rounded-md px-2 py-2.5 bg-gray-50 font-mono text-gray-600 truncate">
                    {draft.lat != null ? `${draft.lat.toFixed(6)}, ${draft.lon.toFixed(6)}` : "ยังไม่ได้ระบุพิกัด"}
                  </div>
                  <button
                    type="button"
                    onClick={handleUseLocation}
                    disabled={locating}
                    className="shrink-0 flex items-center gap-1.5 bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-md px-3 py-2.5 disabled:opacity-60"
                  >
                    {locating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <LocateFixed className="w-3.5 h-3.5" />}
                    ใช้ตำแหน่งปัจจุบัน
                  </button>
                </div>
              </div>

              <TextField label="ทำเล / ที่อยู่" value={draft.location} onChange={(v) => setDraft({ ...draft, location: v })} />
              <div>
                <label className="text-[10px] font-bold uppercase text-gray-400">หมายเหตุ</label>
                <textarea value={draft.note} onChange={(e) => setDraft({ ...draft, note: e.target.value })} rows={2} className="mt-1 w-full text-sm border border-gray-200 rounded-md px-2 py-2 bg-gray-50 font-medium resize-none" />
              </div>
              <button onClick={handleSave} disabled={saving} className="w-full mt-2 bg-neutral-900 text-amber-400 font-black uppercase tracking-wide text-sm rounded-full py-3 flex items-center justify-center gap-2 active:scale-[0.98] transition-transform disabled:opacity-60">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                บันทึกทรัพย์สิน
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ---------- catalog tab ----------

function ListingCard({ listing, onOpen, selectMode, selected, onToggleSelect }) {
  const Icon = TYPE_ICON[listing.propertyType] || Tag;
  return (
    <button
      onClick={() => (selectMode ? onToggleSelect(listing.id) : onOpen(listing))}
      className={`w-full text-left bg-white rounded-2xl border overflow-hidden shadow-sm active:scale-[0.98] transition-transform ${selected ? "border-amber-400 ring-1 ring-amber-300" : "border-gray-100"}`}
    >
      <div className="flex">
        <div className="w-24 h-24 shrink-0 bg-gray-100 relative">
          <img src={listing.image} alt="" className="w-full h-full object-cover" />
          {listing.aiAnalyzed && <div className="absolute bottom-0 left-0 right-0 bg-emerald-600/90 text-white text-[8px] font-black uppercase tracking-wider text-center py-0.5">AI</div>}
          {selectMode && (
            <div className={`absolute top-1.5 left-1.5 w-5 h-5 rounded-md border-2 flex items-center justify-center ${selected ? "bg-amber-400 border-amber-400" : "bg-white/80 border-gray-300"}`}>
              {selected && <Check className="w-3.5 h-3.5 text-neutral-900" strokeWidth={3} />}
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0 p-3">
          <div className="flex items-center gap-1.5">
            <TypeDot type={listing.propertyType} />
            <span className="text-[10px] font-black uppercase tracking-wider text-gray-500 truncate">{listing.propertyType || "ไม่ระบุประเภท"}</span>
            {listing.dealType && <span className="text-[9px] font-bold bg-neutral-900 text-amber-400 px-1.5 py-0.5 rounded shrink-0">{listing.dealType}</span>}
          </div>
          <div className="font-black text-neutral-800 truncate mt-0.5">{listing.price || "ไม่ระบุราคา"}</div>
          <div className="flex items-center gap-1 text-xs text-gray-500 mt-1 font-mono truncate">
            <Phone className="w-3 h-3 shrink-0" /> {listing.phone || "—"}
          </div>
          <div className="text-[10px] text-gray-400 mt-1 truncate">{timeAgo(listing.createdAt)}</div>
        </div>
        {!selectMode && <ChevronRight className="w-4 h-4 text-gray-300 self-center mr-2 shrink-0" />}
      </div>
    </button>
  );
}

function CatalogTab({ listings, loading, onOpen, onNavigate, compareIds, onToggleCompare, onGoToCompare }) {
  const [query, setQuery] = useState("");
  const [dealFilter, setDealFilter] = useState("ทั้งหมด");
  const [selectMode, setSelectMode] = useState(false);

  const filtered = listings.filter((l) => {
    const matchesDeal = dealFilter === "ทั้งหมด" || (l.dealType || "").includes(dealFilter);
    const q = query.trim().toLowerCase();
    const matchesQuery = !q || [l.propertyType, l.price, l.phone, l.contactName, l.location, l.note].filter(Boolean).some((f) => f.toLowerCase().includes(q));
    return matchesDeal && matchesQuery;
  });

  const countSale = listings.filter((l) => (l.dealType || "").includes("ขาย")).length;
  const countRent = listings.filter((l) => (l.dealType || "").includes("เช่า")).length;

  return (
    <div className="pb-32">
      <div className="px-4 pt-4">
        <div className="flex items-center justify-between mb-2">
          <div className="text-xs text-gray-400 font-medium">มีข้อมูลป้ายเก่าอยู่แล้ว?</div>
          <button onClick={() => onNavigate("import")} className="flex items-center gap-1.5 text-xs font-bold text-emerald-600">
            <FileSpreadsheet className="w-3.5 h-3.5" /> นำเข้าจาก Excel/CSV
          </button>
        </div>
        <div className="flex items-center gap-2 mb-3">
          <div className="flex-1 bg-white border border-gray-200 rounded-full flex items-center px-3 py-2">
            <Search className="w-4 h-4 text-gray-400 mr-2" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ค้นหาราคา เบอร์โทร ทำเล..." className="flex-1 text-sm bg-transparent outline-none placeholder:text-gray-400" />
          </div>
          <button
            onClick={() => setSelectMode((s) => !s)}
            className={`shrink-0 text-xs font-black uppercase tracking-wide rounded-full px-3 py-2.5 ${selectMode ? "bg-neutral-900 text-amber-400" : "bg-white border border-gray-200 text-neutral-700"}`}
          >
            {selectMode ? "เสร็จ" : "เลือกเปรียบเทียบ"}
          </button>
        </div>
        <div className="flex gap-2 mb-2 overflow-x-auto">
          <Chip active={dealFilter === "ทั้งหมด"} onClick={() => setDealFilter("ทั้งหมด")}>ทั้งหมด {listings.length}</Chip>
          <Chip active={dealFilter === "ขาย"} onClick={() => setDealFilter("ขาย")}>ขาย {countSale}</Chip>
          <Chip active={dealFilter === "เช่า"} onClick={() => setDealFilter("เช่า")}>เช่า {countRent}</Chip>
        </div>
      </div>

      <div className="px-4 mt-2 space-y-2.5">
        {loading && (
          <div className="flex items-center justify-center py-16 text-gray-400 gap-2">
            <Loader2 className="w-5 h-5 animate-spin" /> กำลังโหลด...
          </div>
        )}

        {!loading && filtered.length === 0 && listings.length === 0 && (
          <div className="flex flex-col items-center text-center py-16 gap-3">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center">
              <ClipboardList className="w-7 h-7 text-gray-400" />
            </div>
            <div className="font-black uppercase tracking-wide text-neutral-700">ยังไม่มีทรัพย์สินที่บันทึก</div>
            <div className="text-xs text-gray-400 max-w-[220px]">แตะปุ่ม "เก็บป้าย" ด้านล่างเพื่อสแกนป้ายแรกของคุณ</div>
            <button onClick={() => onNavigate("capture")} className="bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-full px-4 py-2 mt-1">เก็บป้ายใหม่</button>
          </div>
        )}

        {!loading && filtered.length === 0 && listings.length > 0 && <div className="text-center py-12 text-sm text-gray-400">ไม่พบรายการที่ตรงกับการค้นหา</div>}

        {filtered.map((l) => (
          <ListingCard
            key={l.id}
            listing={l}
            onOpen={onOpen}
            selectMode={selectMode}
            selected={compareIds.includes(l.id)}
            onToggleSelect={onToggleCompare}
          />
        ))}
      </div>

      {selectMode && compareIds.length > 0 && (
        <div className="fixed bottom-20 left-0 right-0 flex justify-center px-4 z-30">
          <div className="w-full max-w-md bg-neutral-900 rounded-full shadow-xl px-4 py-2.5 flex items-center justify-between gap-3">
            <span className="text-white text-sm font-bold">{compareIds.length} รายการที่เลือก</span>
            <button onClick={onGoToCompare} className="bg-amber-400 text-neutral-900 text-xs font-black uppercase tracking-wide rounded-full px-4 py-2">
              ถัดไป
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- detail modal (property detail page) ----------

function surroundingInfo(listing) {
  const h = hashStr(listing.id + "sur");
  const pick = (min, max, seedShift) => min + ((h >> seedShift) % (max - min + 1));
  return [
    { icon: Store, label: "ร้านค้า/ตลาด", value: `${pick(2, 15, 0)} แห่ง` },
    { icon: GraduationCap, label: "โรงเรียนใกล้สุด", value: `${(pick(3, 20, 4) / 10).toFixed(1)} กม.` },
    { icon: HeartPulse, label: "โรงพยาบาลใกล้สุด", value: `${(pick(5, 35, 8) / 10).toFixed(1)} กม.` },
    { icon: Route, label: "ถนนใหญ่", value: `${pick(50, 800, 12)} ม.` },
  ];
}

function DetailModal({ listing, listings, onClose, onDelete, onUpdate, startEditing, onOpenOther, compareIds, onToggleCompare }) {
  const [editing, setEditing] = useState(!!startEditing);
  const [draft, setDraft] = useState(listing);
  const [copied, setCopied] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [locating, setLocating] = useState(false);

  useEffect(() => {
    setDraft(listing);
    setEditing(!!startEditing);
    setConfirmDelete(false);
  }, [listing, startEditing]);

  if (!listing) return null;

  const coords = listingCoords(listing);
  const perUnit = pricePerUnit(listing.price, listing.sizeInfo);
  const nearby = (listings || []).filter((l) => l.id !== listing.id).slice(0, 5);
  const isComparing = compareIds && compareIds.includes(listing.id);

  const handleSave = () => { onUpdate(draft); setEditing(false); };
  const handleCopy = () => {
    if (!listing.phone) return;
    navigator.clipboard?.writeText(listing.phone).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  const updateLandSize = (field, value) => {
    setDraft((d) => {
      const next = { ...d, [field]: value };
      const formatted = formatRaiNganWah(next.rai, next.ngan, next.wah);
      return { ...next, sizeInfo: formatted || next.sizeInfo };
    });
  };
  const handleUseLocation = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => { setLocating(false); setDraft((d) => ({ ...d, lat: pos.coords.latitude, lon: pos.coords.longitude })); },
      () => setLocating(false),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-neutral-900/60">
      <div className="w-full max-w-md bg-gray-50 rounded-t-3xl max-h-[92vh] overflow-y-auto pb-24">
        <div className="sticky top-0 bg-gray-50 z-10 flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">รายละเอียดทรัพย์สิน</span>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white flex items-center justify-center border border-gray-200">
            <X className="w-4 h-4 text-gray-600" />
          </button>
        </div>

        <img src={listing.image} alt="" className="w-full max-h-64 object-cover" />

        <div className="p-4">
          {!editing ? (
            <>
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black uppercase tracking-wide bg-neutral-900 text-amber-400 px-2 py-1 rounded-full">{listing.propertyType || "ไม่ระบุ"}</span>
                  {listing.dealType && <span className="text-xs font-bold text-gray-500">{listing.dealType}</span>}
                </div>
                <button onClick={() => setEditing(true)} className="flex items-center gap-1 text-xs font-bold text-amber-600">
                  <Pencil className="w-3.5 h-3.5" /> แก้ไข
                </button>
              </div>
              <div className="text-2xl font-black text-neutral-800">{listing.price || "ไม่ระบุราคา"}</div>
              {perUnit && <div className="text-xs text-gray-400 mt-0.5">~{perUnit.toLocaleString()} บาท/หน่วยพื้นที่</div>}

              <div className="mt-3 bg-white rounded-2xl border border-gray-100 px-3">
                <FieldRow icon={Phone} label="เบอร์โทร" value={listing.phone} mono />
                <FieldRow icon={User} label="ผู้ติดต่อ" value={listing.contactName} />
                <FieldRow icon={Ruler} label="ขนาดพื้นที่" value={listing.sizeInfo} />
                <FieldRow icon={MapPin} label="ทำเล / ที่อยู่" value={listing.location} />
                <FieldRow icon={LocateFixed} label="พิกัด GPS" value={listing.lat != null ? `${listing.lat.toFixed(6)}, ${listing.lon.toFixed(6)}` : null} mono />
                <FieldRow icon={Tag} label="หมายเหตุ" value={listing.note} />
              </div>

              <div className="text-[10px] font-mono text-gray-400 mt-2">
                บันทึกเมื่อ {new Date(listing.createdAt).toLocaleString("th-TH")} · ผู้เก็บข้อมูล: เจ้าหน้าที่ภาคสนาม
              </div>

              {/* surrounding info */}
              <div className="mt-4">
                <div className="font-black text-neutral-900 text-sm mb-2">ข้อมูลรอบข้าง</div>
                <div className="grid grid-cols-4 gap-2">
                  {surroundingInfo(listing).map((it, i) => (
                    <div key={i} className="flex flex-col items-center text-center bg-white border border-gray-100 rounded-xl py-2.5 px-1">
                      <it.icon className="w-4 h-4 text-amber-500 mb-1" strokeWidth={2.25} />
                      <div className="text-xs font-black text-neutral-900 leading-none">{it.value}</div>
                      <div className="text-[9px] text-gray-400 font-medium mt-1 leading-tight">{it.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* nearby properties */}
              {nearby.length > 0 && (
                <div className="mt-4">
                  <div className="font-black text-neutral-900 text-sm mb-2">ทรัพย์ใกล้เคียง</div>
                  <div className="flex gap-2.5 overflow-x-auto pb-1">
                    {nearby.map((l) => (
                      <button key={l.id} onClick={() => onOpenOther(l)} className="w-32 shrink-0 bg-white rounded-xl border border-gray-100 overflow-hidden text-left">
                        <img src={l.image} alt="" className="w-full h-20 object-cover" />
                        <div className="p-2">
                          <div className="flex items-center gap-1">
                            <TypeDot type={l.propertyType} className="w-2 h-2" />
                            <span className="text-[9px] text-gray-400 truncate">{l.propertyType || "ไม่ระบุ"}</span>
                          </div>
                          <div className="text-xs font-bold text-neutral-800 truncate">{l.price || "ไม่ระบุราคา"}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2 mt-4">
                {listing.phone && (
                  <>
                    <a href={`tel:${listing.phone.split(",")[0].trim()}`} className="flex-1 bg-emerald-600 text-white font-black uppercase text-xs tracking-wide rounded-full py-3 flex items-center justify-center gap-2">
                      <PhoneCall className="w-4 h-4" /> โทร
                    </a>
                    <button onClick={handleCopy} className="flex-1 bg-white border border-gray-200 font-black uppercase text-xs tracking-wide rounded-full py-3 flex items-center justify-center gap-2 text-gray-600">
                      {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                      {copied ? "คัดลอกแล้ว" : "คัดลอกเบอร์"}
                    </button>
                  </>
                )}
              </div>
              <a href={googleMapsDirUrl(coords.lat, coords.lon)} target="_blank" rel="noopener noreferrer" className="w-full mt-2 bg-gray-50 border border-gray-200 text-neutral-700 font-black uppercase text-xs tracking-wide rounded-full py-3 flex items-center justify-center gap-2">
                <Navigation className="w-4 h-4" /> นำทางไปยังทรัพย์นี้
              </a>

              {!confirmDelete ? (
                <button onClick={() => setConfirmDelete(true)} className="w-full mt-3 text-red-600 font-bold text-xs uppercase tracking-wide flex items-center justify-center gap-1.5 py-2">
                  <Trash2 className="w-3.5 h-3.5" /> ลบรายการนี้
                </button>
              ) : (
                <div className="mt-3 bg-red-50 border border-red-200 rounded-xl p-3">
                  <div className="text-xs text-red-700 font-medium mb-2">ยืนยันการลบรายการนี้ถาวรหรือไม่?</div>
                  <div className="flex gap-2">
                    <button onClick={() => onDelete(listing.id)} className="flex-1 bg-red-600 text-white text-xs font-black uppercase rounded-full py-2">ลบเลย</button>
                    <button onClick={() => setConfirmDelete(false)} className="flex-1 bg-white border border-gray-200 text-xs font-black uppercase rounded-full py-2 text-gray-600">ยกเลิก</button>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold uppercase text-gray-400">ประเภททรัพย์</label>
                  <select value={draft.propertyType} onChange={(e) => setDraft({ ...draft, propertyType: e.target.value })} className="mt-1 w-full text-sm border border-gray-200 rounded-md px-2 py-2 bg-white font-medium">
                    <option value="">เลือก</option>
                    {PROPERTY_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase text-gray-400">ประเภทการขาย</label>
                  <select value={draft.dealType} onChange={(e) => setDraft({ ...draft, dealType: e.target.value })} className="mt-1 w-full text-sm border border-gray-200 rounded-md px-2 py-2 bg-white font-medium">
                    <option value="">เลือก</option>
                    {DEAL_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>
              <TextField label="ราคา" value={draft.price} onChange={(v) => setDraft({ ...draft, price: v })} />
              <TextField label="เบอร์โทร" value={draft.phone} onChange={(v) => setDraft({ ...draft, phone: v })} mono />
              <TextField label="ผู้ติดต่อ / สำนักงาน" value={draft.contactName} onChange={(v) => setDraft({ ...draft, contactName: v })} />

              {draft.propertyType === "ที่ดิน" ? (
                <div>
                  <label className="text-[10px] font-bold uppercase text-gray-400">ขนาดที่ดิน (ไร่ - งาน - ตร.ว.)</label>
                  <div className="grid grid-cols-3 gap-2 mt-1">
                    <input type="number" min="0" inputMode="decimal" value={draft.rai || ""} onChange={(e) => updateLandSize("rai", e.target.value)} placeholder="ไร่" className="text-sm border border-gray-200 rounded-md px-2 py-2 bg-white font-medium text-center" />
                    <input type="number" min="0" inputMode="decimal" value={draft.ngan || ""} onChange={(e) => updateLandSize("ngan", e.target.value)} placeholder="งาน" className="text-sm border border-gray-200 rounded-md px-2 py-2 bg-white font-medium text-center" />
                    <input type="number" min="0" inputMode="decimal" value={draft.wah || ""} onChange={(e) => updateLandSize("wah", e.target.value)} placeholder="ตร.ว." className="text-sm border border-gray-200 rounded-md px-2 py-2 bg-white font-medium text-center" />
                  </div>
                  {draft.sizeInfo && <div className="text-[11px] text-gray-400 mt-1">{draft.sizeInfo}</div>}
                </div>
              ) : (
                <TextField label="ขนาดพื้นที่ (เช่น ตร.ม.)" value={draft.sizeInfo} onChange={(v) => setDraft({ ...draft, sizeInfo: v })} />
              )}

              <div>
                <label className="text-[10px] font-bold uppercase text-gray-400">พิกัด GPS</label>
                <div className="mt-1 flex items-center gap-2">
                  <div className="flex-1 text-xs border border-gray-200 rounded-md px-2 py-2.5 bg-white font-mono text-gray-600 truncate">
                    {draft.lat != null ? `${draft.lat.toFixed(6)}, ${draft.lon.toFixed(6)}` : "ยังไม่ได้ระบุพิกัด"}
                  </div>
                  <button
                    type="button"
                    onClick={handleUseLocation}
                    disabled={locating}
                    className="shrink-0 flex items-center gap-1.5 bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-md px-3 py-2.5 disabled:opacity-60"
                  >
                    {locating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <LocateFixed className="w-3.5 h-3.5" />}
                    ใช้ตำแหน่งปัจจุบัน
                  </button>
                </div>
              </div>

              <TextField label="ทำเล / ที่อยู่" value={draft.location} onChange={(v) => setDraft({ ...draft, location: v })} />
              <div>
                <label className="text-[10px] font-bold uppercase text-gray-400">หมายเหตุ</label>
                <textarea value={draft.note || ""} onChange={(e) => setDraft({ ...draft, note: e.target.value })} rows={2} className="mt-1 w-full text-sm border border-gray-200 rounded-md px-2 py-2 bg-white font-medium resize-none" />
              </div>
              <div className="flex gap-2 pt-1">
                <button onClick={handleSave} className="flex-1 bg-neutral-900 text-amber-400 font-black uppercase text-xs tracking-wide rounded-full py-3 flex items-center justify-center gap-2">
                  <Save className="w-4 h-4" /> บันทึกการแก้ไข
                </button>
                <button onClick={() => { setDraft(listing); setEditing(false); }} className="flex-1 bg-white border border-gray-200 font-black uppercase text-xs tracking-wide rounded-full py-3 text-gray-600">ยกเลิก</button>
              </div>
            </div>
          )}
        </div>

        {!editing && (
          <div className="fixed bottom-0 left-0 right-0 flex justify-center px-4 pb-4 pointer-events-none z-20">
            <button
              onClick={() => onToggleCompare(listing.id)}
              className={`pointer-events-auto w-full max-w-md flex items-center justify-center gap-2 font-black uppercase text-xs tracking-wide rounded-full py-3.5 shadow-xl ${
                isComparing ? "bg-amber-400 text-neutral-900" : "bg-neutral-900 text-amber-400"
              }`}
            >
              <Scale className="w-4 h-4" /> {isComparing ? "อยู่ในรายการเปรียบเทียบแล้ว" : "บันทึกเปรียบเทียบ"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ---------- compare sheet ----------

function ComparePage({ items, onBack, onGoToWorkspace, onRemove }) {
  const [view, setView] = useState("table");

  if (items.length === 0) {
    return (
      <div className="px-4 pt-16 pb-28 flex flex-col items-center text-center gap-3">
        <Scale className="w-10 h-10 text-gray-300" />
        <div className="font-black text-neutral-700">ยังไม่มีรายการเปรียบเทียบ</div>
        <div className="text-xs text-gray-400 max-w-[220px]">กลับไปเลือกทรัพย์จากแคตตาล็อกเพื่อเริ่มเปรียบเทียบ</div>
        <button onClick={onBack} className="bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-full px-4 py-2">กลับไปเลือกทรัพย์</button>
      </div>
    );
  }

  const [subject, ...comps] = items;
  const ppus = comps.map((c) => pricePerUnit(c.price, c.sizeInfo)).filter(Boolean);
  const avgPPU = average(ppus);
  const medPPU = median(ppus);
  const minPPU = ppus.length ? Math.min(...ppus) : null;
  const maxPPU = ppus.length ? Math.max(...ppus) : null;

  const markers = items.map((l, i) => {
    const c = listingCoords(l);
    const Icon = TYPE_ICON[l.propertyType] || Tag;
    return { id: l.id, lat: c.lat, lon: c.lon, color: i === 0 ? "bg-purple-600" : TYPE_COLOR[l.propertyType] || "bg-neutral-400", Icon };
  });

  return (
    <div className="px-4 pt-4 pb-40 space-y-4">
      <div>
        <div className="text-lg font-black text-neutral-900 tracking-tight">COMPARE</div>
        <div className="text-xs text-gray-400 font-medium mt-0.5">เปรียบเทียบข้อมูล (Comparable)</div>
      </div>

      <div className="flex bg-gray-100 rounded-full p-1">
        <button onClick={() => setView("table")} className={`flex-1 text-xs font-black uppercase tracking-wide rounded-full py-2 transition-colors ${view === "table" ? "bg-neutral-900 text-amber-400" : "text-gray-500"}`}>
          ตารางเปรียบเทียบ
        </button>
        <button onClick={() => setView("map")} className={`flex-1 text-xs font-black uppercase tracking-wide rounded-full py-2 transition-colors ${view === "map" ? "bg-neutral-900 text-amber-400" : "text-gray-500"}`}>
          แผนที่เปรียบเทียบ
        </button>
      </div>

      {view === "map" ? (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3">
          <TileMap center={listingCoords(subject)} zoom={15} markers={markers} height="h-64" interactive={true} showControls={false} />
          <div className="text-[10px] text-gray-400 mt-2 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-purple-600 inline-block" /> ทรัพย์หลัก (Subject) · หมุดอื่นคือ Comparable
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-x-auto">
          <table className="min-w-full text-xs">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="text-left font-bold text-gray-400 px-3 py-2.5 sticky left-0 bg-white">รายการ</th>
                <th className="text-left font-black text-neutral-900 px-3 py-2.5 bg-amber-50">Subject</th>
                {comps.map((c, i) => (
                  <th key={c.id} className="text-left font-black text-neutral-900 px-3 py-2.5">
                    <div className="flex items-center gap-1">
                      Comp {i + 1}
                      <button onClick={() => onRemove(c.id)}><X className="w-3 h-3 text-gray-400" /></button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {COMPARE_ROWS.map((row) => (
                <tr key={row.label} className="border-b border-gray-50 last:border-b-0">
                  <td className="px-3 py-2 text-gray-400 font-bold sticky left-0 bg-white whitespace-nowrap">{row.label}</td>
                  <td className="px-3 py-2 font-semibold text-neutral-800 bg-amber-50/50 whitespace-nowrap">{row.get(subject, subject)}</td>
                  {comps.map((c) => (
                    <td key={c.id} className="px-3 py-2 text-neutral-700 whitespace-nowrap">{row.get(c, subject)}</td>
                  ))}
                </tr>
              ))}
              <tr>
                <td className="px-3 py-2 text-gray-400 font-bold sticky left-0 bg-white whitespace-nowrap">ความคล้ายคลึงกับ Subject</td>
                <td className="px-3 py-2 bg-amber-50/50">-</td>
                {comps.map((c) => (
                  <td key={c.id} className="px-3 py-2 font-black text-emerald-600 whitespace-nowrap">{comparableScore(subject, c)}%</td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {ppus.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-2.5">สรุปการเปรียบเทียบ</div>
          <div className="grid grid-cols-3 gap-2">
            <div className="text-center">
              <div className="text-[10px] text-gray-400">ราคาเฉลี่ย (บาท/หน่วย)</div>
              <div className="text-sm font-black text-neutral-900">{avgPPU ? avgPPU.toLocaleString() : "-"}</div>
            </div>
            <div className="text-center">
              <div className="text-[10px] text-gray-400">มัธยฐาน (Median)</div>
              <div className="text-sm font-black text-neutral-900">{medPPU ? medPPU.toLocaleString() : "-"}</div>
            </div>
            <div className="text-center">
              <div className="text-[10px] text-gray-400">ช่วงราคา (บาท/หน่วย)</div>
              <div className="text-sm font-black text-neutral-900">{minPPU ? `${minPPU.toLocaleString()}-${maxPPU.toLocaleString()}` : "-"}</div>
            </div>
          </div>
        </div>
      )}

      {comps.length > 0 && (
        <div>
          <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-2">Comparable Score</div>
          <div className="grid grid-cols-3 gap-2">
            {comps.map((c, i) => {
              const score = comparableScore(subject, c);
              return (
                <div key={c.id} className="bg-white border border-gray-100 rounded-xl py-3 text-center">
                  <div className="text-[10px] text-gray-400 font-bold">Comp {i + 1}</div>
                  <div className={`text-lg font-black ${score >= 85 ? "text-emerald-600" : score >= 70 ? "text-amber-500" : "text-gray-400"}`}>{score}%</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="fixed bottom-20 left-0 right-0 flex justify-center px-4 z-30">
        <div className="w-full max-w-md flex gap-2">
          <button onClick={onBack} className="flex-1 bg-white border border-gray-200 text-neutral-700 text-xs font-black uppercase tracking-wide rounded-full py-3 shadow-lg">เลือก Comparable</button>
          <button onClick={onGoToWorkspace} className="flex-1 bg-amber-400 text-neutral-900 text-xs font-black uppercase tracking-wide rounded-full py-3 shadow-lg">ไปยัง Workspace</button>
        </div>
      </div>
    </div>
  );
}

function WorkspacePage({ subject, comps, notes, onAddNote, onGoToExport }) {
  const [tabView, setTabView] = useState("property");
  const [noteText, setNoteText] = useState("");

  const est = valuationEstimate(subject, comps);
  const markers = [subject, ...comps].map((l, i) => {
    const c = listingCoords(l);
    const Icon = TYPE_ICON[l.propertyType] || Tag;
    return { id: l.id, lat: c.lat, lon: c.lon, color: i === 0 ? "bg-purple-600" : TYPE_COLOR[l.propertyType] || "bg-neutral-400", Icon };
  });

  const tabs = [
    { key: "property", label: "ข้อมูลทรัพย์" },
    { key: "comparable", label: "Comparable" },
    { key: "map", label: "แผนที่" },
    { key: "nearby", label: "Smart Nearby" },
    { key: "notes", label: "หมายเหตุ" },
  ];

  return (
    <div className="px-4 pt-4 pb-40 space-y-4">
      <div>
        <div className="text-lg font-black text-neutral-900 tracking-tight">VALUATION WORKSPACE</div>
        <div className="text-xs text-gray-400 font-medium mt-0.5">พื้นที่ทำงานสำหรับการประเมินราคา</div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3 flex items-center gap-3">
        <img src={subject.image} alt="" className="w-14 h-14 rounded-lg object-cover shrink-0" />
        <div className="min-w-0 flex-1">
          <div className="text-[10px] text-gray-400 font-bold uppercase">Subject Asset</div>
          <div className="text-sm font-black text-neutral-900 truncate">{subject.price || subject.propertyType}</div>
          <div className="text-[11px] text-gray-400 truncate">{subject.location || "ไม่ระบุที่อยู่"}</div>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-0.5">
        {tabs.map((t) => (
          <Chip key={t.key} active={tabView === t.key} onClick={() => setTabView(t.key)}>{t.label}</Chip>
        ))}
      </div>

      {tabView === "property" && (
        <div className="bg-white rounded-2xl border border-gray-100 px-3">
          <FieldRow icon={Tag} label="ประเภททรัพย์" value={subject.propertyType} />
          <FieldRow icon={Ruler} label="ขนาดพื้นที่" value={subject.sizeInfo} />
          <FieldRow icon={Scale} label="ราคาเสนอขาย" value={subject.price} />
          <FieldRow icon={Phone} label="เบอร์โทรผู้ขาย" value={subject.phone} mono />
          <FieldRow icon={MapPin} label="ทำเล" value={subject.location} />
          <FieldRow icon={Tag} label="หมายเหตุ" value={subject.note} />
        </div>
      )}

      {tabView === "comparable" && (
        comps.length === 0 ? (
          <div className="text-center text-sm text-gray-400 py-10">ยังไม่มี Comparable ที่เลือก</div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-x-auto">
            <table className="min-w-full text-xs">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left font-bold text-gray-400 px-3 py-2.5 sticky left-0 bg-white">รายการ</th>
                  {comps.map((c, i) => <th key={c.id} className="text-left font-black text-neutral-900 px-3 py-2.5">Comp {i + 1}</th>)}
                </tr>
              </thead>
              <tbody>
                {COMPARE_ROWS.map((row) => (
                  <tr key={row.label} className="border-b border-gray-50 last:border-b-0">
                    <td className="px-3 py-2 text-gray-400 font-bold sticky left-0 bg-white whitespace-nowrap">{row.label}</td>
                    {comps.map((c) => <td key={c.id} className="px-3 py-2 text-neutral-700 whitespace-nowrap">{row.get(c, subject)}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      )}

      {tabView === "map" && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3">
          <TileMap center={listingCoords(subject)} zoom={15} markers={markers} height="h-56" interactive={true} showControls={false} />
        </div>
      )}

      {tabView === "nearby" && (
        <div className="grid grid-cols-4 gap-2">
          {surroundingInfo(subject).map((it, i) => (
            <div key={i} className="flex flex-col items-center text-center bg-white border border-gray-100 rounded-xl py-2.5 px-1">
              <it.icon className="w-4 h-4 text-amber-500 mb-1" strokeWidth={2.25} />
              <div className="text-xs font-black text-neutral-900 leading-none">{it.value}</div>
              <div className="text-[9px] text-gray-400 font-medium mt-1 leading-tight">{it.label}</div>
            </div>
          ))}
        </div>
      )}

      {tabView === "notes" && (
        <div className="space-y-3">
          {notes.length === 0 ? (
            <div className="text-center text-sm text-gray-400 py-6">ยังไม่มีบันทึกความคิดเห็น</div>
          ) : (
            notes.map((n) => (
              <div key={n.id} className="bg-white rounded-xl border border-gray-100 p-3">
                <div className="text-sm text-neutral-800">{n.text}</div>
                <div className="text-[10px] text-gray-400 mt-1">{timeAgo(n.createdAt)}</div>
              </div>
            ))
          )}
          <div className="flex items-center gap-2">
            <input
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              placeholder="ระบุความคิดเห็นเพิ่มเติม..."
              className="flex-1 text-sm border border-gray-200 rounded-full px-4 py-2.5 bg-gray-50 min-w-0"
            />
            <button
              onClick={() => { if (noteText.trim()) { onAddNote(noteText.trim()); setNoteText(""); } }}
              className="w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center shrink-0"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {(tabView === "property" || tabView === "comparable") && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-2.5">Market Summary (จาก Comparable ที่เลือก)</div>
          {est ? (
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="text-center">
                <div className="text-[10px] text-gray-400">ราคาเฉลี่ย (บาท/หน่วย)</div>
                <div className="text-sm font-black text-neutral-900">{est.avgPPU.toLocaleString()}</div>
              </div>
              <div className="text-center">
                <div className="text-[10px] text-gray-400">มัธยฐาน (Median)</div>
                <div className="text-sm font-black text-neutral-900">{est.medPPU.toLocaleString()}</div>
              </div>
              <div className="text-center">
                <div className="text-[10px] text-gray-400">ช่วงราคา</div>
                <div className="text-sm font-black text-neutral-900">{est.rangePPU[0].toLocaleString()}-{est.rangePPU[1].toLocaleString()}</div>
              </div>
            </div>
          ) : (
            <div className="text-xs text-gray-400 mb-4">ข้อมูลไม่เพียงพอสำหรับคำนวณ (ต้องมีราคาและขนาดพื้นที่ของ Comparable และ Subject)</div>
          )}

          <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-2.5">สรุปมูลค่าประเมินเบื้องต้น</div>
          {est ? (
            <div className="grid grid-cols-2 gap-2 bg-purple-50 rounded-xl p-3">
              <div className="text-center">
                <div className="text-[10px] text-gray-500">ช่วงมูลค่า (บาท)</div>
                <div className="text-sm font-black text-purple-700">{est.low.toLocaleString()} - {est.high.toLocaleString()}</div>
              </div>
              <div className="text-center">
                <div className="text-[10px] text-gray-500">มูลค่ากลาง (บาท)</div>
                <div className="text-base font-black text-purple-700">{est.mid.toLocaleString()}</div>
              </div>
            </div>
          ) : (
            <div className="text-xs text-gray-400">ยังไม่สามารถประเมินได้</div>
          )}
        </div>
      )}

      <div className="fixed bottom-20 left-0 right-0 flex justify-center px-4 z-30">
        <button onClick={onGoToExport} className="w-full max-w-md bg-neutral-900 text-amber-400 text-xs font-black uppercase tracking-wide rounded-full py-3.5 shadow-lg flex items-center justify-center gap-2">
          <Share2 className="w-4 h-4" /> ไปยัง Export
        </button>
      </div>
    </div>
  );
}

function ExportPage({ subject, comps, notes, onToast }) {
  const [formats, setFormats] = useState({ excel: true, pdf: true, csv: true });
  const [options, setOptions] = useState({ images: true, map: true, comparable: true, nearby: true, notes: true });
  const [history, setHistory] = useState([]);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const idx = await window.storage.get("export-history");
        if (idx) setHistory(JSON.parse(idx.value));
      } catch (e) {}
    })();
  }, []);

  const toggleFormat = (k) => setFormats((p) => ({ ...p, [k]: !p[k] }));
  const toggleOption = (k) => setOptions((p) => ({ ...p, [k]: !p[k] }));

  const buildRows = () => {
    const rows = [["รายการ", "Subject", ...comps.map((_, i) => `Comp ${i + 1}`)]];
    COMPARE_ROWS.forEach((row) => rows.push([row.label, row.get(subject, subject), ...comps.map((c) => row.get(c, subject))]));
    if (options.comparable && comps.length) {
      rows.push([]);
      rows.push(["Comparable Score"]);
      comps.forEach((c, i) => rows.push([`Comp ${i + 1}`, `${comparableScore(subject, c)}%`]));
    }
    const est = valuationEstimate(subject, comps);
    if (est) {
      rows.push([]);
      rows.push(["สรุปมูลค่าประเมิน"]);
      rows.push(["ช่วงมูลค่า (บาท)", `${est.low.toLocaleString()} - ${est.high.toLocaleString()}`]);
      rows.push(["มูลค่ากลาง (บาท)", est.mid.toLocaleString()]);
    }
    if (options.nearby) {
      rows.push([]);
      rows.push(["ข้อมูลรอบข้าง"]);
      surroundingInfo(subject).forEach((it) => rows.push([it.label, it.value]));
    }
    if (options.notes && notes.length) {
      rows.push([]);
      rows.push(["หมายเหตุผู้ประเมิน"]);
      notes.forEach((n) => rows.push([new Date(n.createdAt).toLocaleString("th-TH"), n.text]));
    }
    if (options.images) {
      rows.push([]);
      rows.push(["รูปภาพ", "แนบอยู่ในแอป (ไม่รวมไฟล์ภาพในเอกสารนี้)"]);
    }
    return rows;
  };

  const saveHistory = async (record) => {
    setHistory((prev) => {
      const next = [record, ...prev].slice(0, 20);
      window.storage.set("export-history", JSON.stringify(next)).catch(() => {});
      return next;
    });
  };

  const downloadBlob = (blob, filename) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  };

  const exportCSV = (rows, filename) => {
    const csv = rows.map((r) => r.map((cell) => `"${String(cell ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
    downloadBlob(new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8;" }), filename);
  };

  const exportXLSX = (rows, filename) => {
    const ws = XLSX.utils.aoa_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Valuation");
    XLSX.writeFile(wb, filename);
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const rows = buildRows();
      const stamp = new Date();
      const base = `Valuation_${subject.id.slice(0, 6)}_${stamp.toISOString().slice(0, 10).replace(/-/g, "")}`;
      const created = [];
      if (formats.csv) { exportCSV(rows, `${base}.csv`); created.push({ format: "csv", filename: `${base}.csv` }); }
      if (formats.excel) { exportXLSX(rows, `${base}.xlsx`); created.push({ format: "xlsx", filename: `${base}.xlsx` }); }
      if (formats.pdf) { created.push({ format: "pdf", filename: `${base}.pdf` }); window.print(); }
      for (const c of created) {
        await saveHistory({ id: uid(), filename: c.filename, format: c.format, createdAt: stamp.toISOString() });
      }
      if (created.length) onToast("ส่งออกข้อมูลเรียบร้อยแล้ว");
      else onToast("กรุณาเลือกรูปแบบไฟล์อย่างน้อย 1 แบบ");
    } catch (e) {
      onToast("ส่งออกไม่สำเร็จ ลองใหม่อีกครั้ง");
    } finally {
      setExporting(false);
    }
  };

  const est = valuationEstimate(subject, comps);
  const anyFormat = formats.excel || formats.pdf || formats.csv;
  const rows = buildRows();

  return (
    <div className="px-4 pt-4 pb-28 space-y-4">
      <style>{`
        @media print {
          body * { visibility: hidden; }
          #fieldmate-print-area, #fieldmate-print-area * { visibility: visible; }
          #fieldmate-print-area { position: absolute; top: 0; left: 0; width: 100%; padding: 24px; }
        }
      `}</style>

      <div>
        <div className="text-lg font-black text-neutral-900 tracking-tight">EXPORT</div>
        <div className="text-xs text-gray-400 font-medium mt-0.5">ส่งออกข้อมูลเพื่อนำไปใช้งานต่อ</div>
      </div>

      <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 flex items-center gap-2">
        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
        <div className="text-sm font-bold text-emerald-700">ประเมินมูลค่าเสร็จสมบูรณ์ พร้อมส่งออกข้อมูล</div>
      </div>

      <div>
        <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-2">รูปแบบไฟล์ที่รองรับ</div>
        <div className="grid grid-cols-3 gap-2">
          {[
            { key: "excel", label: "Excel", ext: ".xlsx", color: "bg-emerald-600" },
            { key: "pdf", label: "PDF", ext: ".pdf", color: "bg-red-600" },
            { key: "csv", label: "CSV", ext: ".csv", color: "bg-blue-600" },
          ].map((f) => (
            <button
              key={f.key}
              onClick={() => toggleFormat(f.key)}
              className={`rounded-2xl border-2 p-3 flex flex-col items-center gap-1.5 transition-colors ${formats[f.key] ? "border-neutral-900 bg-white" : "border-gray-100 bg-gray-50 opacity-50"}`}
            >
              <div className={`w-10 h-10 rounded-lg ${f.color} text-white font-black text-[10px] flex items-center justify-center`}>{f.label}</div>
              <div className="text-[10px] text-gray-400">{f.ext}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
        <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-2.5">ตัวเลือกการส่งออก</div>
        <div className="space-y-2.5">
          {[
            { key: "images", label: "รวมรูปภาพ" },
            { key: "map", label: "รวมแผนที่" },
            { key: "comparable", label: "รวมข้อมูล Comparable" },
            { key: "nearby", label: "รวม Smart Nearby" },
            { key: "notes", label: "รวมหมายเหตุผู้ประเมิน" },
          ].map((o) => (
            <button key={o.key} onClick={() => toggleOption(o.key)} className="w-full flex items-center gap-2.5">
              <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 ${options[o.key] ? "bg-emerald-500 border-emerald-500" : "border-gray-300"}`}>
                {options[o.key] && <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />}
              </div>
              <span className="text-sm text-neutral-700">{o.label}</span>
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={handleExport}
        disabled={exporting || !anyFormat}
        className="w-full bg-amber-400 text-neutral-900 font-black uppercase tracking-wide text-sm rounded-full py-3.5 flex items-center justify-center gap-2 disabled:opacity-50"
      >
        {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4 rotate-180" />}
        ส่งออกข้อมูล
      </button>

      <div>
        <div className="text-xs font-black uppercase tracking-wide text-gray-400 mb-2">ประวัติการส่งออก</div>
        {history.length === 0 ? (
          <div className="text-xs text-gray-400 text-center py-6">ยังไม่มีประวัติการส่งออก</div>
        ) : (
          <div className="space-y-2">
            {history.map((h) => (
              <div key={h.id} className="bg-white rounded-xl border border-gray-100 px-3 py-2.5 flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg text-white text-[9px] font-black flex items-center justify-center shrink-0 ${h.format === "xlsx" ? "bg-emerald-600" : h.format === "pdf" ? "bg-red-600" : "bg-blue-600"}`}>
                  {h.format.toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold text-neutral-800 truncate">{h.filename}</div>
                  <div className="text-[10px] text-gray-400">{new Date(h.createdAt).toLocaleString("th-TH")}</div>
                </div>
                <button
                  onClick={() => onToast("ไฟล์นี้ถูกบันทึกไว้ในโฟลเดอร์ดาวน์โหลดของอุปกรณ์คุณแล้วตอนส่งออกครั้งนั้น")}
                  className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center shrink-0"
                >
                  <Save className="w-3.5 h-3.5 text-gray-500" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* hidden printable report, only rendered visible by @media print above */}
      <div id="fieldmate-print-area" className="hidden">
        <h2 style={{ fontWeight: 900, fontSize: 20 }}>FieldMate AI — รายงานการประเมินมูลค่า</h2>
        <p>Subject: {subject.price} · {subject.propertyType} · {subject.location}</p>
        {est && <p>ช่วงมูลค่าประเมิน: {est.low.toLocaleString()} - {est.high.toLocaleString()} บาท (มูลค่ากลาง {est.mid.toLocaleString()} บาท)</p>}
        <table style={{ borderCollapse: "collapse", width: "100%", marginTop: 12 }}>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i}>
                {r.map((cell, j) => (
                  <td key={j} style={{ border: "1px solid #ccc", padding: 6, fontSize: 12 }}>{cell}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------- notification / profile / more sheets ----------

function NotificationSheet({ onClose }) {
  const items = [
    { icon: Camera, text: "มีป้ายใหม่ใกล้คุณ 2 รายการที่ยังไม่ได้บันทึก", time: "5 นาทีที่แล้ว" },
    { icon: Tag, text: "ราคาที่ดินย่านยานนาวาปรับขึ้นเฉลี่ย 5%", time: "2 ชม.ที่แล้ว" },
    { icon: ShieldCheck, text: "พบจุดเตือนภัยใหม่ใกล้ตำแหน่งของคุณ", time: "เมื่อวาน" },
  ];
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-neutral-900/50" onClick={onClose}>
      <div className="w-full max-w-md bg-white rounded-b-3xl shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <span className="font-black text-neutral-900">การแจ้งเตือน</span>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center">
            <X className="w-4 h-4 text-gray-600" />
          </button>
        </div>
        <div className="p-2">
          {items.map((it, i) => (
            <div key={i} className="flex items-start gap-3 px-2 py-3 border-b border-gray-50 last:border-b-0">
              <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center shrink-0">
                <it.icon className="w-4 h-4 text-amber-600" />
              </div>
              <div className="min-w-0">
                <div className="text-sm text-neutral-800 font-medium">{it.text}</div>
                <div className="text-[10px] text-gray-400 mt-0.5">{it.time}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ProfileSheet({ user, listingsCount, onClose, onLogout }) {
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-neutral-900/50" onClick={onClose}>
      <div className="w-full max-w-md bg-white rounded-b-3xl shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <span className="font-black text-neutral-900">โปรไฟล์</span>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center">
            <X className="w-4 h-4 text-gray-600" />
          </button>
        </div>
        <div className="p-4 flex items-center gap-3">
          <div className="w-14 h-14 rounded-full bg-gray-200 flex items-center justify-center">
            <User className="w-7 h-7 text-gray-500" />
          </div>
          <div>
            <div className="font-black text-neutral-900">{user?.name || "เจ้าหน้าที่ภาคสนาม"}</div>
            {user?.phone && <div className="text-xs text-gray-500 font-mono">{user.phone}</div>}
            <div className="text-xs text-gray-400">บันทึกป้ายแล้ว {listingsCount} รายการ</div>
          </div>
        </div>
        <div className="px-4 pb-4">
          <button onClick={() => { onLogout(); onClose(); }} className="w-full flex items-center justify-center gap-2 bg-gray-50 text-red-600 font-black uppercase text-xs tracking-wide rounded-full py-3">
            <LogOut className="w-4 h-4" /> ออกจากระบบ
          </button>
        </div>
      </div>
    </div>
  );
}

function MoreSheet({ onClose, onToast, compareCount, onOpenCompare, onGoImport }) {
  const items = [
    { icon: FileSpreadsheet, label: "นำเข้าข้อมูลจาก Excel/CSV", action: () => { onGoImport(); onClose(); } },
    { icon: Scale, label: `เปรียบเทียบทรัพย์ (${compareCount})`, action: () => { onOpenCompare(); onClose(); } },
    { icon: Settings, label: "ตั้งค่า", action: () => { onToast("ฟีเจอร์นี้จะเปิดให้ใช้งานเร็วๆ นี้"); onClose(); } },
    { icon: Info, label: "เกี่ยวกับ FieldMate AI", action: () => { onToast("ฟีเจอร์นี้จะเปิดให้ใช้งานเร็วๆ นี้"); onClose(); } },
    { icon: HelpCircle, label: "ช่วยเหลือ", action: () => { onToast("ฟีเจอร์นี้จะเปิดให้ใช้งานเร็วๆ นี้"); onClose(); } },
  ];
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-neutral-900/50" onClick={onClose}>
      <div className="w-full max-w-md bg-white rounded-t-3xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <span className="font-black text-neutral-900">เมนูเพิ่มเติม</span>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center">
            <X className="w-4 h-4 text-gray-600" />
          </button>
        </div>
        <div className="p-2 pb-6">
          {items.map((it, i) => (
            <button key={i} onClick={it.action} className="w-full flex items-center gap-3 px-3 py-3.5 rounded-xl active:bg-gray-50">
              <it.icon className="w-4.5 h-4.5 text-neutral-700" />
              <span className="text-sm font-semibold text-neutral-800">{it.label}</span>
              <ChevronRight className="w-4 h-4 text-gray-300 ml-auto" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ---------- bottom nav ----------

function BottomNav({ tab, onChange, onOpenMore }) {
  const items = [
    { key: "home", label: "หน้าหลัก", icon: HomeIcon },
    { key: "map", label: "แผนที่", icon: MapIcon },
    { key: "capture", label: "เก็บป้าย", icon: Camera, center: true },
    { key: "catalog", label: "แคตตาล็อก", icon: Database },
    { key: "more", label: "เมนูเพิ่มเติม", icon: MenuIcon },
  ];
  return (
    <div className="fixed bottom-0 w-full max-w-md bg-white border-t border-gray-100 flex items-end px-1 pt-2 z-30" style={{ paddingBottom: "calc(0.5rem + env(safe-area-inset-bottom))" }}>
      {items.map((it) =>
        it.center ? (
          <button key={it.key} onClick={() => onChange("capture")} className="flex-1 flex flex-col items-center gap-1 -translate-y-5">
            <div className="w-14 h-14 rounded-full bg-amber-400 flex items-center justify-center shadow-lg shadow-amber-400/40 border-4 border-white">
              <it.icon className="w-6 h-6 text-neutral-900" strokeWidth={2.25} />
            </div>
            <span className={`text-[10px] font-bold ${tab === "capture" ? "text-neutral-900" : "text-gray-400"}`}>{it.label}</span>
          </button>
        ) : (
          <button key={it.key} onClick={() => (it.key === "more" ? onOpenMore() : onChange(it.key))} className="flex-1 flex flex-col items-center gap-1 py-1.5">
            <it.icon className={`w-5 h-5 ${tab === it.key ? "text-neutral-900" : "text-gray-400"}`} strokeWidth={tab === it.key ? 2.5 : 2} />
            <span className={`text-[10px] font-bold ${tab === it.key ? "text-neutral-900" : "text-gray-400"}`}>{it.label}</span>
            {tab === it.key && <span className="w-1 h-1 rounded-full bg-amber-400 mt-0.5" />}
          </button>
        )
      )}
    </div>
  );
}

// ---------- login ----------

function LoginScreen({ onLogin }) {
  const [mode, setMode] = useState("login"); // login | register
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (mode === "register" && !name.trim()) { setError("กรุณากรอกชื่อ-นามสกุล"); return; }
    if (!phone.trim()) { setError("กรุณากรอกเบอร์โทรศัพท์"); return; }
    if (!password.trim()) { setError("กรุณากรอกรหัสผ่าน"); return; }
    setError("");
    setSubmitting(true);
    setTimeout(() => {
      onLogin({ name: name.trim() || "เจ้าหน้าที่ภาคสนาม", phone: phone.trim() });
    }, 500);
  };

  const handleGuest = () => onLogin({ name: "ผู้ใช้ทดลอง", phone: "", guest: true });

  return (
    <div className="min-h-screen bg-gray-50 flex justify-center font-sans" style={{ minHeight: "100dvh" }}>
      <div className="w-full max-w-md min-h-screen bg-white relative flex flex-col" style={{ minHeight: "100dvh" }}>
        <div className="bg-neutral-900 px-6 pt-16 pb-14 flex flex-col items-center text-center relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-amber-400/20" />
          <div className="absolute -bottom-16 -left-10 w-40 h-40 rounded-full bg-amber-400/10" />
          <div className="w-16 h-16 rounded-2xl bg-amber-400 flex items-center justify-center shadow-lg shadow-amber-400/30 relative z-10">
            <Camera className="w-8 h-8 text-neutral-900" strokeWidth={2} />
          </div>
          <div className="text-2xl font-black tracking-tight text-white mt-4 relative z-10">
            FIELDMATE <span className="text-amber-400">AI</span>
          </div>
          <div className="text-xs text-gray-400 font-medium mt-1 relative z-10">Smart Field Survey · Smarter Valuation</div>
        </div>

        <div className="flex-1 -mt-6 bg-white rounded-t-3xl px-6 pt-6 pb-8 relative z-10">
          <div className="flex bg-gray-100 rounded-full p-1 mb-6">
            <button onClick={() => setMode("login")} className={`flex-1 text-xs font-black uppercase tracking-wide rounded-full py-2.5 transition-colors ${mode === "login" ? "bg-neutral-900 text-amber-400" : "text-gray-500"}`}>
              เข้าสู่ระบบ
            </button>
            <button onClick={() => setMode("register")} className={`flex-1 text-xs font-black uppercase tracking-wide rounded-full py-2.5 transition-colors ${mode === "register" ? "bg-neutral-900 text-amber-400" : "text-gray-500"}`}>
              สมัครสมาชิก
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            {mode === "register" && <TextField label="ชื่อ-นามสกุล" value={name} onChange={setName} />}
            <TextField label="เบอร์โทรศัพท์" value={phone} onChange={setPhone} mono />
            <div>
              <label className="text-[10px] font-bold uppercase text-gray-400">รหัสผ่าน</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 w-full text-sm border border-gray-200 rounded-md px-2 py-2 bg-gray-50 font-medium"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-700 text-xs rounded-md px-3 py-2">
                <AlertTriangle className="w-4 h-4 shrink-0" /> {error}
              </div>
            )}

            {mode === "login" && (
              <button type="button" onClick={() => onLogin && setError("") } className="text-right w-full">
                <span className="text-[11px] font-bold text-amber-600">ลืมรหัสผ่าน?</span>
              </button>
            )}

            <button type="submit" disabled={submitting} className="w-full bg-neutral-900 text-amber-400 font-black uppercase tracking-wide text-sm rounded-full py-3.5 flex items-center justify-center gap-2 active:scale-[0.98] transition-transform disabled:opacity-60">
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {mode === "login" ? "เข้าสู่ระบบ" : "สมัครสมาชิก"}
            </button>
          </form>

          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-gray-100" />
            <span className="text-[10px] text-gray-400 font-bold uppercase">หรือ</span>
            <div className="flex-1 h-px bg-gray-100" />
          </div>

          <button onClick={handleGuest} className="w-full bg-amber-400 text-neutral-900 font-black uppercase tracking-wide text-sm rounded-full py-3.5">
            เข้าใช้งานแบบทดลอง (Demo)
          </button>

          <div className="text-center text-[10px] text-gray-400 mt-6 leading-relaxed">
            การเข้าสู่ระบบถือว่ายอมรับ<br />ข้อกำหนดการใช้งานและนโยบายความเป็นส่วนตัว
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- app shell ----------

export default function FieldMateAI() {
  const [authChecked, setAuthChecked] = useState(false);
  const [user, setUser] = useState(null);
  const [tab, setTab] = useState("home");
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [selectedEditing, setSelectedEditing] = useState(false);
  const [toast, setToast] = useState("");
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [compareIds, setCompareIds] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [favoriteIds, setFavoriteIds] = useState([]);
  const [nearbyCategory, setNearbyCategory] = useState("all");
  const toastTimer = useRef(null);

  const showToast = useCallback((msg) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 2200);
  }, []);

  const loadListings = useCallback(async () => {
    setLoading(true);
    try {
      const idx = await window.storage.get("listings-index");
      const ids = idx ? JSON.parse(idx.value) : [];
      const items = [];
      for (const id of ids) {
        try {
          const r = await window.storage.get(`listing:${id}`);
          if (!r) continue;
          const meta = JSON.parse(r.value);
          // image is stored separately (listing-image:{id}) so a large photo
          // never blocks the small metadata write from succeeding; fall back to
          // meta.image for older listings saved before this split existed
          let image = meta.image || PLACEHOLDER_IMAGE;
          try {
            const imgR = await window.storage.get(`listing-image:${id}`);
            if (imgR) image = imgR.value;
          } catch (e) {}
          items.push({ ...meta, image });
        } catch (e) {}
      }
      setListings(items);
    } catch (e) {
      setListings([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadListings(); }, [loadListings]);

  const loadIncidents = useCallback(async () => {
    try {
      const idx = await window.storage.get("incidents-index");
      if (!idx) {
        // first run: seed with two illustrative demo reports so Safety isn't empty
        const seed = [
          { id: uid(), type: "สุนัขดุ", note: "", distanceM: 120, status: "ยืนยันแล้ว", createdAt: new Date(Date.now() - 3600_000).toISOString() },
          { id: uid(), type: "ก่อสร้าง", note: "ถนนปิดเลนซ้าย", distanceM: 350, status: "รอตรวจสอบ", createdAt: new Date(Date.now() - 7200_000).toISOString() },
        ];
        for (const inc of seed) await window.storage.set(`incident:${inc.id}`, JSON.stringify(inc));
        await window.storage.set("incidents-index", JSON.stringify(seed.map((s) => s.id)));
        setIncidents(seed);
        return;
      }
      const ids = JSON.parse(idx.value);
      const items = [];
      for (const id of ids) {
        try {
          const r = await window.storage.get(`incident:${id}`);
          if (r) items.push(JSON.parse(r.value));
        } catch (e) {}
      }
      setIncidents(items.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
    } catch (e) {
      setIncidents([]);
    }
  }, []);

  useEffect(() => { loadIncidents(); }, [loadIncidents]);

  const handleAddIncident = async ({ type, note, distanceM }) => {
    const inc = { id: uid(), type, note, distanceM, status: "รอตรวจสอบ", createdAt: new Date().toISOString() };
    try {
      await window.storage.set(`incident:${inc.id}`, JSON.stringify(inc));
      const idx = await window.storage.get("incidents-index");
      const ids = idx ? JSON.parse(idx.value) : [];
      ids.unshift(inc.id);
      await window.storage.set("incidents-index", JSON.stringify(ids));
    } catch (e) {}
    setIncidents((prev) => [inc, ...prev]);
    showToast("ส่งรายงานเหตุการณ์เรียบร้อยแล้ว");
  };

  const handleConfirmIncident = async (id) => {
    const updated = incidents.map((i) => (i.id === id ? { ...i, status: "ยืนยันแล้ว" } : i));
    setIncidents(updated);
    const inc = updated.find((i) => i.id === id);
    try { await window.storage.set(`incident:${id}`, JSON.stringify(inc)); } catch (e) {}
    showToast("ยืนยันเหตุการณ์แล้ว");
  };

  useEffect(() => {
    (async () => {
      try {
        const r = await window.storage.get("favorites");
        if (r) setFavoriteIds(JSON.parse(r.value));
      } catch (e) {}
    })();
  }, []);

  const toggleFavorite = async (id) => {
    setFavoriteIds((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      window.storage.set("favorites", JSON.stringify(next)).catch(() => {});
      return next;
    });
  };

  useEffect(() => {
    (async () => {
      try {
        const r = await window.storage.get("session:user");
        if (r) setUser(JSON.parse(r.value));
      } catch (e) {}
      setAuthChecked(true);
    })();
  }, []);

  const handleLogin = async (u) => {
    setUser(u);
    try { await window.storage.set("session:user", JSON.stringify(u)); } catch (e) {}
  };

  const handleLogout = async () => {
    setUser(null);
    setTab("home");
    try { await window.storage.delete("session:user"); } catch (e) {}
  };

  const handleSaved = (listing) => setListings((prev) => [listing, ...prev]);
  const handleImported = (newListings) => setListings((prev) => [...newListings, ...prev]);

  const handleDelete = async (id) => {
    try {
      await storageDelete(`listing:${id}`);
      try { await storageDelete(`listing-image:${id}`); } catch (e) {}
      const idx = await storageGet("listings-index");
      const ids = idx ? JSON.parse(idx.value).filter((x) => x !== id) : [];
      await storageSet("listings-index", JSON.stringify(ids));
      setListings((prev) => prev.filter((l) => l.id !== id));
      setCompareIds((prev) => prev.filter((x) => x !== id));
      setSelected(null);
      showToast("ลบรายการแล้ว");
    } catch (e) {
      console.error("[App] handleDelete failed:", e);
      showToast("ลบรายการไม่สำเร็จ กรุณาลองอีกครั้ง");
    }
  };

  const handleUpdate = async (updated) => {
    try {
      // image lives in its own storage key (listing-image:{id}) and isn't
      // re-uploaded from the edit form, so keep the metadata write small
      const { image, ...meta } = updated;
      await storageSet(`listing:${updated.id}`, JSON.stringify(meta));
      setListings((prev) => prev.map((l) => (l.id === updated.id ? updated : l)));
      setSelected(updated);
      showToast("บันทึกการแก้ไขแล้ว");
    } catch (e) {
      console.error("[App] handleUpdate failed:", e);
      showToast("บันทึกการแก้ไขไม่สำเร็จ กรุณาลองอีกครั้ง");
    }
  };

  const openListing = (l, editing = false) => { setSelected(l); setSelectedEditing(editing); };

  const toggleCompare = (id) => {
    setCompareIds((prev) => {
      if (prev.includes(id)) { showToast("นำออกจากรายการเปรียบเทียบแล้ว"); return prev.filter((x) => x !== id); }
      if (prev.length >= 5) { showToast("เปรียบเทียบได้สูงสุด 5 รายการ"); return prev; }
      showToast("เพิ่มเข้ารายการเปรียบเทียบแล้ว");
      return [...prev, id];
    });
  };

  const compareItems = compareIds.map((id) => listings.find((l) => l.id === id)).filter(Boolean);
  const subjectId = compareIds[0] || null;

  const [valuationNotes, setValuationNotes] = useState([]);
  useEffect(() => {
    if (!subjectId) { setValuationNotes([]); return; }
    (async () => {
      try {
        const r = await window.storage.get(`valuation-notes:${subjectId}`);
        setValuationNotes(r ? JSON.parse(r.value) : []);
      } catch (e) {
        setValuationNotes([]);
      }
    })();
  }, [subjectId]);

  const handleAddNote = async (text) => {
    if (!subjectId) return;
    const note = { id: uid(), text, createdAt: new Date().toISOString() };
    const next = [note, ...valuationNotes];
    setValuationNotes(next);
    try { await window.storage.set(`valuation-notes:${subjectId}`, JSON.stringify(next)); } catch (e) {}
    showToast("บันทึกหมายเหตุแล้ว");
  };

  if (!authChecked) {
    return (
      <div className="min-h-screen bg-neutral-900 flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex justify-center font-sans" style={{ minHeight: "100dvh" }}>
      <div className="w-full max-w-md min-h-screen bg-gray-50 relative flex flex-col" style={{ minHeight: "100dvh" }}>
        <AppHeader
          tab={tab}
          onBell={() => setNotifOpen(true)}
          onProfile={() => setProfileOpen(true)}
          onBack={() => {
            if (tab === "compare") setTab("catalog");
            else if (tab === "workspace") setTab("compare");
            else if (tab === "export") setTab("workspace");
            else if (tab === "import") setTab("catalog");
            else setTab("home");
          }}
        />

        <div className="flex-1 overflow-y-auto" style={{ minHeight: 0 }}>
          {tab === "home" && (
            <HomeTab listings={listings} incidents={incidents} onNavigate={setTab} onToast={showToast} onOpenListing={(l) => openListing(l, false)} />
          )}
          {tab === "map" && (
            <MapTab
              listings={listings}
              onOpenListing={(l) => openListing(l, false)}
              onEditListing={(l) => openListing(l, true)}
              onNavigate={setTab}
              onToast={showToast}
            />
          )}
          {tab === "capture" && <CaptureTab onSaved={handleSaved} goToTab={setTab} onToast={showToast} />}
          {tab === "catalog" && (
            <CatalogTab
              listings={listings}
              loading={loading}
              onOpen={(l) => openListing(l, false)}
              onNavigate={setTab}
              compareIds={compareIds}
              onToggleCompare={toggleCompare}
              onGoToCompare={() => setTab("compare")}
            />
          )}
          {tab === "nearby" && (
            <NearbyTab listings={listings} favoriteIds={favoriteIds} onToggleFavorite={toggleFavorite} onOpenListing={(l) => openListing(l, false)} initialCategory={nearbyCategory} />
          )}
          {tab === "import" && <ImportPage onImported={handleImported} onBack={() => setTab("catalog")} onToast={showToast} />}
          {tab === "safety" && <SafetyTab incidents={incidents} onAddIncident={handleAddIncident} onConfirmIncident={handleConfirmIncident} />}
          {tab === "compare" && (
            <ComparePage items={compareItems} onBack={() => setTab("catalog")} onGoToWorkspace={() => setTab("workspace")} onRemove={toggleCompare} />
          )}
          {tab === "workspace" && compareItems.length > 0 && (
            <WorkspacePage
              subject={compareItems[0]}
              comps={compareItems.slice(1)}
              notes={valuationNotes}
              onAddNote={handleAddNote}
              onGoToExport={() => setTab("export")}
            />
          )}
          {tab === "workspace" && compareItems.length === 0 && (
            <div className="px-4 pt-16 text-center text-sm text-gray-400">ยังไม่มีทรัพย์ที่เลือก กลับไปที่แคตตาล็อกเพื่อเลือกทรัพย์ก่อน</div>
          )}
          {tab === "export" && compareItems.length > 0 && (
            <ExportPage subject={compareItems[0]} comps={compareItems.slice(1)} notes={valuationNotes} onToast={showToast} />
          )}
        </div>

        <BottomNav tab={tab} onChange={setTab} onOpenMore={() => setMoreOpen(true)} />

        {selected && (
          <DetailModal
            listing={selected}
            listings={listings}
            onClose={() => setSelected(null)}
            onDelete={handleDelete}
            onUpdate={handleUpdate}
            startEditing={selectedEditing}
            onOpenOther={(l) => openListing(l, false)}
            compareIds={compareIds}
            onToggleCompare={toggleCompare}
          />
        )}
        {notifOpen && <NotificationSheet onClose={() => setNotifOpen(false)} />}
        {profileOpen && <ProfileSheet user={user} listingsCount={listings.length} onClose={() => setProfileOpen(false)} onLogout={handleLogout} />}
        {moreOpen && (
          <MoreSheet onClose={() => setMoreOpen(false)} onToast={showToast} compareCount={compareIds.length} onOpenCompare={() => setTab("compare")} onGoImport={() => setTab("import")} />
        )}

        <Toast message={toast} />
      </div>
    </div>
  );
}
